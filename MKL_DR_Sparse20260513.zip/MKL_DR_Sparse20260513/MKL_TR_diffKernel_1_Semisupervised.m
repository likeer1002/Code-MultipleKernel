function [ave_ACC,var_ACC,ave_traintime_TR,var_traintime_TR,ave_testtime_TR,var_testtime_TR,ave_betas]...
    =MKL_TR_diffKernel_1_Semisupervised(times,DataBase,lambda,step1,max_IT1,step2,max_IT2,p1,p)
%  ��MKL_TR����Multiple kernel dimensionality reduction via spectral regression and trace ratio maximization
global KernelTypes KernelPostProcessTypes Degrees;
time_TR_train=zeros(times,1);
time_TR_test=zeros(times,1);
m=length(Degrees);
Betas=zeros(m,times);

for j = 1:times
tstart=tic;
     file = strcat('semi','_',DataBase,'\','Train\',num2str(p),'\',int2str(j),'.mat');
%      file = strcat(DataBase,'\','Train\',int2str(j),'.mat');

     load(file, 'trainfea','traingnd');
     [feaLabel,gndLabel,feaTrain] = Partial_Label(trainfea,traingnd,0.1); % %����ǩ����ռѵ����������0.1
     nclass=length(unique(gndLabel));  %�ܹ��������
     ReducedDim=nclass-1;
     feaAll = [feaLabel;feaTrain];
     n=size(feaAll,1);  %ѵ������������  

    options=[];
    options.NeighborMode = 'KNN';
    options.k = 15;
    options.WeightMode = 'Binary';
    S = constructW(feaAll,options);  %����S in (45)
    options=[];
    options.NeighborMode = 'Supervised';
    options.gnd = gndLabel;  %����ǩ������gnd
    options.bLDA = 1;     
    M = constructW(feaLabel,options); 
    M=blkdiag(M,zeros(size(feaTrain,1)));
M=M+0.1*S;   %����W in (43)   ,sparse Affinity matrix
M=diag(sum(M,2))-M;  %sparse matrix
    W_tilde=1/size(feaLabel,1)*ones(size(feaLabel,1));
    W_tilde=blkdiag(W_tilde,zeros(size(feaTrain,1)));  %����W' in (44)
N=sparse(diag(sum(W_tilde,2))-W_tilde);

KERNELS=zeros(n,n,m);
for i=1:m
    kernel_option = [];
     switch lower(KernelTypes{i})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(i);
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(i);
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(i);
                  kernel=constructKernel(trainfea,[],kernel_option);
                  kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
     end
KERNELS(:,:,i)=kernel;
end

r=1;
f_r=1;
it=1;

while f_r~=0 && it<max_IT1
    [A,betas]=MKL_TR_ADM_1(KERNELS,N,M,n,ReducedDim,r,step2,max_IT2,m,lambda); %Alternating projections
    Kernel=zeros(n,n);
  for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
  
% %      [~,deltas_D]=eig(Kernel*(W-r*diag(D))*Kernel-r*lambda*eye(n));
%     [~,deltas_D]=eig(Kernel*(W-r*diag(D))*Kernel-r*lambda*eye(n),Kernel+1e-6*eye(n));
%     [deltas_D,~]=sort(diag(deltas_D),'descend');
%     f_r=sum(deltas_D(1:ReducedDim));

    f_r_1=Kernel*A;
    f_r=trace(f_r_1'*((M-r*N)*f_r_1))-r*lambda*norm(A,'fro')^2;
%     C=N.^(1/2).*f_r_1;
    d_f_r=-trace(f_r_1'*N*f_r_1)-lambda*norm(A,'fro')^2;
    r=r-step1*f_r/d_f_r;
    
  it=it+1;
end   %end while
time_TR_train(j)=toc(tstart);
Betas(:,j)=betas;
 %%%--------- Data projected in the learned representation space-----------
tstart_test=tic;

%%%-----------------------------------------------%%%
load(file, 'testfea','testgnd');
ntest=size(testfea,1);
m11=floor(p1*ntest);  %�˾���n*ntest�����в����У�ÿ�βɵ�����  
p11=floor(1/p1);  %�˾���n*ntest�����в����У��ɵĴ���  
testData = zeros(ntest,size(A,2));    % size(A,2)=nclass-1
for i =1:p11
    Kernel_sub=zeros(n,m11); 
    Rtestfea=testfea((i-1)*m11+1:i*m11,:);
   for jj=1:m
     kernel_option = [];
     switch lower(KernelTypes{jj})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(jj);
                        Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                        Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
    end 
        Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
  end
    testData_no = A'*Kernel_sub;
    testData((i-1)*m11+1:i*m11,:)=testData_no';
end
clear Rtestfea Kernel_sub_1 Kernel_sub
if ntest-m11*p11>0
Kernel_sub=zeros(n,ntest-m11*p11);
Rtestfea=testfea(m11*p11+1:ntest,:);
  for jj=1:m
     kernel_option = [];
     switch lower(KernelTypes{jj})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(jj);
                        Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                        Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
    end 
        Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
  end
testData_no=A'*Kernel_sub;
testData(m11*p11+1:ntest,:)=testData_no';
clear Rtestfea Kernel_sub_1 Kernel_sub testfea
end

label=litekmeans(testData,nclass,'MaxIter',100,'Replicates',10);
result(j,:) = ClusteringMeasure(testgnd,label);
time_TR_test(j)=toc(tstart_test);
end %end times

ave_ACC=mean(result(:,1));    var_ACC=var(result(:,1));
% ave_NMI=mean(result(:,2));    var_NMI=var(result(:,2));
% ave_RI=mean(result(:,3));    var_RI=var(result(:,3));
ave_traintime_TR=mean(time_TR_train);  var_traintime_TR=var(time_TR_train);
ave_testtime_TR=mean(time_TR_test);   var_testtime_TR=var(time_TR_test);
ave_betas=mean(Betas,2);
end

