function [ave_ACC,var_ACC,ave_NMI,var_NMI,ave_RI,var_RI,ave_traintime_TR,var_traintime_TR,ave_testtime_TR,var_testtime_TR,ave_betas]...
    =MKL_TR_diffKernel_1_Unsupervised(times,DataBase,lambda,step1,max_IT1,step2,max_IT2,p1,p)
%  ��MKL_TR����Multiple kernel dimensionality reduction via spectral regression and trace ratio maximization
global KernelTypes KernelPostProcessTypes Degrees;
time_TR_train=zeros(times,1);
time_TR_test=zeros(times,1);
m=length(Degrees);
Betas=zeros(m,times);

for j = 1:times
tstart=tic;
     file = strcat('un','_',DataBase,'\','Train\',num2str(p),'\',int2str(j),'.mat');
%      file = strcat(DataBase,'\','Train\',int2str(j),'.mat');

     load(file, 'trainfea','traingnd');
%      eval(['load ' DataBase, '\','Train\',int2str(j),'.mat']); 
     nclass=length(unique(traingnd));  %�ܹ��������
     ReducedDim=nclass-1;
     n=size(trainfea,1);  %ѵ������������

      options = [];
      options.NeighborMode = 'KNN';
      options.k = 15;
      options.WeightMode = 'Binary';
W = constructW(trainfea,options); %%% sparse Affinity matrix
D=full(sum(W,2));   %Column vector
% D=sparse(diag(D));   % Diagonal matrix  D
KERNELS=zeros(n,n,m);
for i=1:m
    kernel_option = [];
     switch lower(KernelTypes{i})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(i);
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(i);
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel,KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(i);
                  kernel=constructKernel(trainfea,[],kernel_option);
                  kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
     end
KERNELS(:,:,i)=kernel;
end

r=1;
f_r=1;
it=1;

while f_r~=0 && it<max_IT1
    [A,betas]=MKL_TR_ADM_1(KERNELS,D,W,n,ReducedDim,r,step2,max_IT2,m,lambda); %Alternating projections
    Kernel=zeros(n,n);
  for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
  
% %      [~,deltas_D]=eig(Kernel*(W-r*diag(D))*Kernel-r*lambda*eye(n));
%     [~,deltas_D]=eig(Kernel*(W-r*diag(D))*Kernel-r*lambda*eye(n),Kernel+1e-6*eye(n));
%     [deltas_D,~]=sort(diag(deltas_D),'descend');
%     f_r=sum(deltas_D(1:ReducedDim));

    f_r_1=Kernel*A;
    f_r=trace(f_r_1'*((W-r*diag(D))*f_r_1))-r*lambda*norm(A,'fro')^2;
    C=D.^(1/2).*f_r_1;
    d_f_r=-norm(C,'fro')^2-lambda*norm(A,'fro')^2;
    r=r-step1*f_r/d_f_r;
    
  it=it+1;
end   %end while
time_TR_train(j)=toc(tstart);
Betas(:,j)=betas;
 %%%--------- Data projected in the learned representation space-----------
tstart_test=tic;

%%%--------------------�޼ල������---------------------------%%%
%�޼ලû��ѵ����, �һ��˾��������ʽ�γɲ��洢������ֱ�ӵ��� KERNELS(:,:,i)=kernel;
Kernel=zeros(n,n);
for jj=1:m
    Kernel=Kernel+betas(jj)*KERNELS(:,:,jj);  %The mixed kernel,
end
trainData = A'*Kernel;
trainData=trainData';
label=litekmeans(trainData,nclass,'MaxIter',100,'Replicates',10);
result(j,:) = ClusteringMeasure(traingnd,label);

time_TR_test(j)=toc(tstart_test);
end %end times

ave_ACC=mean(result(:,1));    var_ACC=var(result(:,1));
ave_NMI=mean(result(:,2));    var_NMI=var(result(:,2));
ave_RI=mean(result(:,3));    var_RI=var(result(:,3));
ave_traintime_TR=mean(time_TR_train);  var_traintime_TR=var(time_TR_train);
ave_testtime_TR=mean(time_TR_test);   var_testtime_TR=var(time_TR_test);
ave_betas=mean(Betas,2);
end

