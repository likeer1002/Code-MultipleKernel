function [time,error_1,error_2,error_3,ave_accuracy,var_accuracy,ave_traintime_OURS,var_traintime_OURS,ave_betas]...
    =OurSparseMethod(times,DataBase,width,tol2,max_IT2,max_IT,p1,betas_tol)
%  Our Sparse method--Computing A by Nystrom method--�����ݣ����Թ��̣�,
%   Computing betas by adding a regularization term
accuracy=zeros(times,1);
time_OURS_train=zeros(times,1);
m=length(width);
Betas=zeros(m,times);

for j = 1:times
tstart=tic;
     betas=ones(m,1)/m;
     file = strcat(DataBase,'\','Train\',int2str(j),'.mat');
     load(file, 'trainfea','traingnd');
%      eval(['load ' DataBase, '\','Train\',int2str(j),'.mat']); 
     nclass=length(unique(traingnd));  %�ܹ��������
     ReducedDim=nclass-1;
     n=size(trainfea,1);  %ѵ������������
     M = calM(trainfea,width,p1); %�˾���֮�������Ծ���
     
%       options = [];
%       options.NeighborMode = 'KNN';
%       options.k = 5;
%       options.WeightMode = 'HeatKernel';
      options = [];
      options.NeighborMode = 'Supervised';
      options.gnd = traingnd;
      options.bLDA = 1;
%       options.WeightMode = 'HeatKernel';   
W = constructW(trainfea,options); %%% sparse sAffinity matrix
D=full(sum(W,2)); %column vector
% t_1=tic;
% W=kron(W,eye(ReducedDim,ReducedDim));
% D=D.^(-1);
% D=diag(D); % Diagonal matrix  D
% D_inverse=kron(D,eye(ReducedDim,ReducedDim));
% t_11=toc(t_1) 
IT=1;
while IT<max_IT
 %%%-----------Optimizacion of A (projection matrix)--------------
 t_2=tic;
    Label = unique(traingnd);
    rand('state',0);
    Y = rand(nclass,nclass);
    Z = zeros(n,nclass);
    for i=1:nclass
        idx = find(traingnd==Label(i));
        Z(idx,:) = repmat(Y(i,:),length(idx),1);
    end
    Z(:,1) = ones(n,1);
    [Y,~] = qr(Z,0);
    Y(:,1) = [];
    clear Z
t_22=toc(t_2)

t_3=tic;
% [A,err_A(j),IT_A(j),time_Decom_A(j)]=MYBlockREKcol_multiple_A(trainfea,Y,betas,tol1,max_IT1,width); 
% A=orth(A);
A=Nystrom_A(trainfea,Y,betas,width,p1);
t_33=toc(t_3)
%%%-----------Optimizing Betas (Kernel weights)--------------
% t_4=tic;
%  Y = rand(n,ReducedDim+1);
%  Y(:,1) = ones(n,1);
%  [Y,~] = qr(Y,0);
%  Y(:,1) = [];
% y=reshape(Y,n*ReducedDim,1);
% clear Y
% % [y,~] = eigs(D_inverse*W,1) ; 
% t_44=toc(t_4)

t_5=tic;
[betas,time,error_1,error_2,error_3]=UpdateWeights(trainfea,A,M,D,W,tol2,max_IT2,ReducedDim,width,p1,betas_tol); 
t_55=toc(t_5)


IT=IT+1;
end %\end while
time_OURS_train(j)=toc(tstart);
Betas(:,j)=betas;
%%%----�����棺m���˾���KERNELS�Լ�һ��mixed�˾���Kernel-------%%%
%%%--------- Data projected in the learned representation space-----------

m11=floor(p1*n);  %�˾���n*n�����в����У�ÿ�βɵ�����  
p11=floor(1/p1);  %�˾���n*n�����в����У��ɵĴ��� 
trainData = zeros(n,size(A,2));    % size(A,2)=nclass-1
for i =1:p11
    Kernel_sub=zeros(m11,n); 
    Rtrainfea=trainfea((i-1)*m11+1:i*m11,:);
  for jj=1:m
    options=[];
    options.KernelType = 'Gaussian';
    options.t=width(jj);
    Kernel_sub_1=zeros(m11,n); 
    Kernel_sub_1=constructKernel(Rtrainfea,trainfea,options);
    Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
  end
    trainData((i-1)*m11+1:i*m11,:) = Kernel_sub*A;
end
clear Rtrainfea Kernel_sub_1 Kernel_sub
if n-m11*p11>0
Kernel_sub=zeros(n-m11*p11,n);
Rtrainfea=trainfea(m11*p11+1:n,:);
  for jj=1:m
    options=[];
    options.KernelType = 'Gaussian';
    options.t=width(jj);
    Kernel_sub_1=zeros(n-m11*p11,n); 
    Kernel_sub_1=constructKernel(Rtrainfea,trainfea,options);
    Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
  end
% Kernel_sub=Kernel(m11*p11+1:end,:);
trainData(m11*p11+1:n,:) = Kernel_sub*A;
clear Rtrainfea Kernel_sub_1 Kernel_sub
end

%%%-----------------------------------------------%%%
load(file, 'testfea','testgnd');
ntest=size(testfea,1);
m11=floor(p1*ntest);  %�˾���n*ntest�����в����У�ÿ�βɵ�����  
p11=floor(1/p1);  %�˾���n*ntest�����в����У��ɵĴ���  
testData = zeros(ntest,size(A,2));    % size(A,2)=nclass-1
for i =1:p11
    Kernel_sub=zeros(n,m11); 
    Rtestfea=testfea((i-1)*m11+1:i*m11,:);
  for jj=1:m
    options=[];
    options.KernelType = 'Gaussian';
    options.t=width(jj);
    Kernel_sub_1=zeros(n,m11); 
    Kernel_sub_1=constructKernel(trainfea,Rtestfea,options);
    Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
  end
    testData_no = A'*Kernel_sub;
    testData((i-1)*m11+1:i*m11,:)=testData_no';
end
clear Rtestfea Kernel_sub_1 Kernel_sub
if ntest-m11*p11>0
Kernel_sub=zeros(n,ntest-m11*p11);
Rtestfea=testfea(m11*p11+1:ntest,:);
  for jj=1:m
    options=[];
    options.KernelType = 'Gaussian';
    options.t=width(jj);
    Kernel_sub_1=zeros(n,ntest-m11*p11); 
    Kernel_sub_1=constructKernel(trainfea,Rtestfea,options);
    Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
  end
testData_no=A'*Kernel_sub;
testData(m11*p11+1:ntest,:)=testData_no';
clear Rtestfea Kernel_sub_1 Kernel_sub testfea
end

accuracy(j)=NN(trainData,testData,traingnd,testgnd);
% model_linear = svmtrain(traingnd, trainData, '-t 0');
% [~, accuracy_1, ~] = svmpredict(testgnd, testData, model_linear);
% accuracy(j)=accuracy_1(1);
end%\end times
ave_accuracy=mean(accuracy);    var_accuracy=var(accuracy);
ave_traintime_OURS=mean(time_OURS_train);  var_traintime_OURS=var(time_OURS_train);
ave_betas=mean(Betas,2);
end
