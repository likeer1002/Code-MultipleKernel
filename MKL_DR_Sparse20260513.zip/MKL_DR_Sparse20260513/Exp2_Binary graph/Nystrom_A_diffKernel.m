function A=Nystrom_A_diffKernel(trainfea,Y,betas,p1)
global KernelTypes KernelPostProcessTypes Degrees;
m=length(Degrees);
n=size(trainfea,1);
m1=floor(p1*n);
k=m1-10; 
idx = randperm(n); % uniform sampling without replacement 
cols = idx(1:m1);    % m columns indexes
Rtrainfea=trainfea(cols,:);
%%%--------computing some columns,i.e., C-------%%%%%

C=zeros(n,m1);
for j=1:m
     kernel_option = [];
     switch lower(KernelTypes{j})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(j);
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(j);
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(j);
                        kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                        kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
     end
        C=C+betas(j)*kernel_sub;
end
clear kernel_sub trainfea Rtrainfea
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
W = C(cols,:);  
W=max(W,W');% m-by-m intersection matrix
[Q,R] = qr (C,0); % thin QR decomposition of matrix C
W =R * pinv(W) * R'; 
W=max(W,W');
[V,D,~] = svd(W,'econ');
V=V(:,1:k);
D=D(1:k,1:k);
% DD=diag(D);
V=Q*V;
A=V*((diag(D).^(-1)).*(V'*Y));
%%%-------����Nystrom�����Ľ���Ч��---------%%%
% K_app=V*D*V';
% KERNELS=zeros(n,n,m);
% for i=1:m
%     options=[];
%     options.KernelType = 'Gaussian';
%     options.t=width(i);
%    KERNELS(:,:,i) = constructKernel(trainfea,[],options);
% end
% Kernel=zeros(n,n);
% for j=1:m
%     Kernel=Kernel+betas(j)*KERNELS(:,:,j);
% end
% err = norm ( Kernel-K_app, 'fro')/norm(Kernel,'fro');
% err_1=norm(Kernel*A-Y,'fro');
% err_2=norm(Kernel*A-Y,'fro')/norm(Y,'fro');
end


