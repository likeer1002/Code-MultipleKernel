function [Betas]...
    =OurSparse_diffK_Precond_Unsupervised(times,DataBase,tol2,max_IT2,max_IT,p1,betas_tol,gamma,lambda,step1)
%  Our Sparse method--Computing A by Nystrom method--�����ݣ����Թ��̣�,
%   Computing betas by adding a regularization term, ��ѡ��ı����˾���
global   Degrees;
% accuracy=zeros(times,1);
time_OURS_train=zeros(times,1);
% time_OURS_test=zeros(times,1);
m=length(Degrees);
Betas=zeros(m,times);

for j = 1:times
     file = strcat(DataBase,'_sub','.mat');
     load(file, 'fea_sub','gnd_sub');
tstart=tic;
     betas=ones(m,1)/m;
     betas_0=zeros(m,1);
%      eval(['load ' DataBase, '\','Train\',int2str(j),'.mat']); 
     nclass=length(unique(gnd_sub));  %�ܹ��������
     ReducedDim=3;
%      n=size(trainfea,1);  %ѵ������������
t_1=tic;
%      M = calM_diffKernel(trainfea,p1);
%      b=sum(M,2);
     bb = calM_diffKernel_Parallel(fea_sub,p1); %�˾���֮�������Ծ���M���к�
     
t_11=toc(t_1)
t_1_1=tic;
      options = [];
      options.NeighborMode = 'KNN';
      options.k = 15;
      options.WeightMode = 'Binary';
W = constructW(fea_sub,options); %%% sparse Affinity matrix
D=full(sum(W,2));   %Column vector
t_12=toc(t_1_1)
% t_1=tic;
% W=kron(W,eye(ReducedDim,ReducedDim));
% D=D.^(-1);
% D=diag(D); % Diagonal matrix  D
% D_inverse=kron(D,eye(ReducedDim,ReducedDim));
% t_11=toc(t_1) 

t_2=tic;
Y = Eigenmap(W,ReducedDim);
t_22=toc(t_2)

IT=1;
while IT<max_IT  && norm(betas-betas_0,inf)>=1e-2 && nnz(betas)/length(betas)>=0.5
 %%%-----------Optimizacion of A (projection matrix)--------------
betas_0=betas;
t_3=tic;
% [A,err_A(j),IT_A(j),time_Decom_A(j)]=MYBlockREKcol_multiple_A(trainfea,Y,betas,tol1,max_IT1,width); 
% A=orth(A);
A=Nystrom_A_1_diffKernel(fea_sub,Y,betas,p1,betas_tol);
t_33=toc(t_3)
%%%-----------Optimizing Betas (Kernel weights)--------------
% t_4=tic;
%  Y = rand(n,ReducedDim+1);
%  Y(:,1) = ones(n,1);
%  [Y,~] = qr(Y,0);
%  Y(:,1) = [];
% y=reshape(Y,n*ReducedDim,1);
% clear Y
% % [y,~] = eigs(D_inverse*W,1) ; 
% t_44=toc(t_4)

t_5=tic;
% [betas,b,error_1,error_2,error_3]=UpdateWeights_diffK_Paral(trainfea,A,bb,D,W,tol2,max_IT2,ReducedDim,p1,betas_tol,gamma,lambda,TrueOrFalse); 
[betas,b]=UpdateWeight_diffK_Paral_ourKaczmarz_1(betas,fea_sub,A,bb,D,W,tol2,max_IT2,ReducedDim,p1,betas_tol,gamma,lambda); 

t_55=toc(t_5)

% lambda_update=b'*(kron(diag(D),eye(ReducedDim)))*b;
lambda=lambda-step1*(norm(b)-1);



BIG_betas(:,IT,j)=betas;
IT=IT+1;
end %\end while
time_OURS_train(j)=toc(tstart);
Betas(:,j)=betas;
% %%----�����棺m���˾���KERNELS�Լ�һ��mixed�˾���Kernel-------%%%
% %%--------- Data projected in the learned representation space-----------
% tstart_test=tic;
% 
% m11=floor(p1*n);  %�˾���n*n�����в����У�ÿ�βɵ�����  
% p11=floor(1/p1);  %�˾���n*n�����в����У��ɵĴ��� 
% trainData = zeros(n,size(A,2));    % size(A,2)=nclass-1
% for i =1:p11
%     Kernel_sub=zeros(m11,n); 
%     Rtrainfea=trainfea((i-1)*m11+1:i*m11,:);
% for jj=1:m
%    if betas(jj)>betas_tol
%      kernel_option = [];
%      switch lower(KernelTypes{jj})
%         case lower('Linear')
%             kernel_option.KernelType = 'Linear';
%             for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(Rtrainfea,trainfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%             end
%         case lower('Polynomial')
%             kernel_option.KernelType = 'Polynomial';
%                 kernel_option.d = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(Rtrainfea,trainfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         case lower('PolyPlus')
%             kernel_option.KernelType = 'PolyPlus';
%                 kernel_option.d = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(Rtrainfea,trainfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         case lower('Gaussian')
%             kernel_option.KernelType = 'Gaussian';
%                 kernel_option.t = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                         Kernel_sub_1 = constructKernel(Rtrainfea,trainfea, kernel_option);
%                         Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         otherwise
%             error('KernelType does not exist!');
%     end    
%         Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
%     end
% end
%     trainData((i-1)*m11+1:i*m11,:) = Kernel_sub*A;
% end
% clear Rtrainfea Kernel_sub_1 Kernel_sub
% if n-m11*p11>0
% Kernel_sub=zeros(n-m11*p11,n);
% Rtrainfea=trainfea(m11*p11+1:n,:);
%   for jj=1:m
%      if betas(jj)>betas_tol
%      kernel_option = [];
%      switch lower(KernelTypes{jj})
%         case lower('Linear')
%             kernel_option.KernelType = 'Linear';
%             for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(Rtrainfea,trainfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%             end
%         case lower('Polynomial')
%             kernel_option.KernelType = 'Polynomial';
%                 kernel_option.d = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(Rtrainfea,trainfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         case lower('PolyPlus')
%             kernel_option.KernelType = 'PolyPlus';
%                 kernel_option.d = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(Rtrainfea,trainfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         case lower('Gaussian')
%             kernel_option.KernelType = 'Gaussian';
%                 kernel_option.t = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                         Kernel_sub_1 = constructKernel(Rtrainfea,trainfea, kernel_option);
%                         Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         otherwise
%             error('KernelType does not exist!');
%     end  
%         Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
%     end
%   end
% % Kernel_sub=Kernel(m11*p11+1:end,:);
% trainData(m11*p11+1:n,:) = Kernel_sub*A;
% clear Rtrainfea Kernel_sub_1 Kernel_sub
% end
% 
% %%%-----------------------------------------------%%%
% load(file, 'testfea','testgnd');
% ntest=size(testfea,1);
% m11=floor(p1*ntest);  %�˾���n*ntest�����в����У�ÿ�βɵ�����  
% p11=floor(1/p1);  %�˾���n*ntest�����в����У��ɵĴ���  
% testData = zeros(ntest,size(A,2));    % size(A,2)=nclass-1
% for i =1:p11
%     Kernel_sub=zeros(n,m11); 
%     Rtestfea=testfea((i-1)*m11+1:i*m11,:);
%   for jj=1:m
%      if betas(jj)>betas_tol
%      kernel_option = [];
%      switch lower(KernelTypes{jj})
%         case lower('Linear')
%             kernel_option.KernelType = 'Linear';
%             for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%             end
%         case lower('Polynomial')
%             kernel_option.KernelType = 'Polynomial';
%                 kernel_option.d = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         case lower('PolyPlus')
%             kernel_option.KernelType = 'PolyPlus';
%                 kernel_option.d = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         case lower('Gaussian')
%             kernel_option.KernelType = 'Gaussian';
%                 kernel_option.t = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                         Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
%                         Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         otherwise
%             error('KernelType does not exist!');
%     end 
%         Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
%     end
%   end
%     testData_no = A'*Kernel_sub;
%     testData((i-1)*m11+1:i*m11,:)=testData_no';
% end
% clear Rtestfea Kernel_sub_1 Kernel_sub
% if ntest-m11*p11>0
% Kernel_sub=zeros(n,ntest-m11*p11);
% Rtestfea=testfea(m11*p11+1:ntest,:);
%   for jj=1:m
%      if betas(jj)>betas_tol
%      kernel_option = [];
%      switch lower(KernelTypes{jj})
%         case lower('Linear')
%             kernel_option.KernelType = 'Linear';
%             for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%             end
%         case lower('Polynomial')
%             kernel_option.KernelType = 'Polynomial';
%                 kernel_option.d = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         case lower('PolyPlus')
%             kernel_option.KernelType = 'PolyPlus';
%                 kernel_option.d = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                     Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
%                     Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         case lower('Gaussian')
%             kernel_option.KernelType = 'Gaussian';
%                 kernel_option.t = Degrees(jj);
%                 for iPost = KernelPostProcessTypes
%                         Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
%                         Kernel_sub_1 = KernelNormalize(Kernel_sub_1, iPost{1});%#ok
%                 end
%         otherwise
%             error('KernelType does not exist!');
%     end 
%         Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
%     end
%   end
% testData_no=A'*Kernel_sub;
% testData(m11*p11+1:ntest,:)=testData_no';
% clear Rtestfea Kernel_sub_1 Kernel_sub testfea
% end
% 
% accuracy(j)=NN(trainData,testData,traingnd,testgnd);
% 
% time_OURS_test(j)=toc(tstart_test);
% % model_linear = svmtrain(traingnd, trainData, '-t 0');
% % [~, accuracy_1, ~] = svmpredict(testgnd, testData, model_linear);
% % accuracy(j)=accuracy_1(1);
end%\end times  
% ave_accuracy=mean(accuracy);    var_accuracy=var(accuracy);
ave_traintime_OURS=mean(time_OURS_train);  var_traintime_OURS=var(time_OURS_train);
% ave_testtime_OURS=mean(time_OURS_test);  var_testtime_OURS=var(time_OURS_test);
% ave_betas=mean(Betas,2);
% memusage=memusage_1+memusage_2_minres;
end
