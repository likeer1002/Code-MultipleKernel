close all
clc
%%
    DataBase='ORL_32x32';
%     DataBase='PIE_32x32';
    file = strcat(DataBase,'_sub','.mat');
    load(file,'gnd_sub');
    [gnd_sub,c]=sort(gnd_sub,'ascend');  %����
%     testData1=testData2;  %������
    testData1=testData1(c,:); %��ά������ݾ���

    a=[];
    for i=1:length(unique(gnd_sub))
    b=find(gnd_sub==i);
    a=[a,b];
    end
    color=['k','r','g','y','b','m'];
    shape=['+','*','^','h','s','o'];
%% Plot
    figure  %2άʹ��scatter������3άʹ��scatter3����
%     scatter(testData1(a(:,1),1),testData1(a(:,1),2),68,color(1),shape(1),'LineWidth',1.2);
    scatter3(testData1(a(:,1),1),testData1(a(:,1),2),testData1(a(:,1),3),68,color(1),shape(1),'LineWidth',1.2);
    hold on
    for j=2:length(unique(gnd_sub))
%     scatter(testData1(a(:,j),1),testData1(a(:,j),2),68,color(j),shape(j),'LineWidth',1.2);
    scatter3(testData1(a(:,j),1),testData1(a(:,j),2),testData1(a(:,j),3),68,color(j),shape(j),'LineWidth',1.2);
       if j==length(unique(gnd_sub))
        hold off 
       else
        hold on
       end
    end

    
    
    
    