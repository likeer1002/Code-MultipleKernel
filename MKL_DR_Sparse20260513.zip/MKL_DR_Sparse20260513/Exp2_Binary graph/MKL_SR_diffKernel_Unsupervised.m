function [testData]...
    =MKL_SR_diffKernel_Unsupervised(times,DataBase,max_IT1,p1)
%  ��MKL_SR����Multiple kernel dimensionality reduction via spectral regression and trace ratio maximization
global KernelTypes KernelPostProcessTypes Degrees;
time_SR_train=zeros(times,1);
time_SR_test=zeros(times,1);
m=length(Degrees);
Betas=zeros(m,times);
for j = 1:times
tstart=tic;
    file = strcat(DataBase,'_sub','.mat');
     load(file, 'fea_sub','gnd_sub');
%      eval(['load ' DataBase, '\','Train\',int2str(j),'.mat']); 
     nclass=length(unique(gnd_sub));  %�ܹ��������
     ReducedDim=3;
     n=size(fea_sub,1);  %ѵ������������

      options = [];
      options.NeighborMode = 'KNN';
      options.k = 15;
      options.WeightMode = 'Binary';
W = constructW(fea_sub,options); %%% sparse Affinity matrix
D=full(sum(W,2));   %Column vector

KERNELS=zeros(n,n,m);
for i=1:m
    kernel_option = [];
     switch lower(KernelTypes{i})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                kernel=constructKernel(fea_sub,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(i);
                kernel=constructKernel(fea_sub,[],kernel_option);
                kernel = KernelNormalize(kernel,KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(i);
                kernel=constructKernel(fea_sub,[],kernel_option);
                kernel = KernelNormalize(kernel,KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(i);
                  kernel=constructKernel(fea_sub,[],kernel_option);
                  kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
     end
KERNELS(:,:,i)=kernel;
end

it=1;
betas=ones(m,1)/m;

%     Label = unique(traingnd);
%     rand('state',0);
%     Y = rand(nclass,nclass);
%     Z = zeros(n,nclass);
%     for i=1:nclass
%         idx = find(traingnd==Label(i));
%         Z(idx,:) = repmat(Y(i,:),length(idx),1);
%     end
%     Z(:,1) = ones(n,1);
%     [Y,~] = qr(Z,0);
%     Y(:,1) = [];
%     clear Z

while it<max_IT1
    %Computine A
    Kernel=zeros(n,n);
  for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
  
      options = [];
      options.W = W;
      options.ReguAlpha = 0.5;
      options.ReguType = 'Ridge';
      options.ReducedDim = ReducedDim;
      options.Kernel = 1;
      A = KSR_caller(options, Kernel);
  %Computine betas
  WW=kron(W,eye(ReducedDim));
  DD=kron(diag(D),eye(ReducedDim));
  LL=DD-WW;
  K_tilde=zeros(n*ReducedDim,m);
  for ii=1:m
     K_tilde(:,ii)=reshape(A'*KERNELS(:,:,ii),n*ReducedDim,1); 
  end
  S_L=(K_tilde)'*LL*K_tilde;
  S_D=(K_tilde)'*DD*K_tilde;
  
  %sdpt3���������

  blk{1,1}='s';
  blk{1,2}=m+1;
  At{1,1}=blkdiag(0,S_D);
  C{1}=blkdiag(0,S_L);
  b=1;
  

  
%   OPTIONS.vers = vers;
OPTIONS=[];
  [X0,y0,Z0] = infeaspt(blk,At,C,b);
  [~,T,~,~,~,~] = sdpt3(blk,At,C,b,OPTIONS,X0,y0,Z0);
  save('T.mat','T');
  
%   betas1=real(T{2});
%   betas=betas1(:,1);
  betas1=full(real(T{1}));
  betas1(1,:)=[];
  betas=betas1(:,1);
  
  betas = quadprog(eye(m,m),-betas,[],[],ones(1,m),1,zeros(m,1),ones(m,1));
  betas(betas<1e-6)=0;
  betas = betas/sum(betas);
  it=it+1;
end   %end while
time_SR_train(j)=toc(tstart);
Betas(:,j)=betas;
 %%%--------- Data projected in the learned representation space-----------
tstart_test=tic;

%%%-----------------------------------------------%%%
load(file, 'fea_sub','gnd_sub');
ntest=size(fea_sub,1);
m11=floor(p1*ntest);  %�˾���n*ntest�����в����У�ÿ�βɵ�����  
p11=floor(1/p1);  %�˾���n*ntest�����в����У��ɵĴ���  
testData = zeros(ntest,size(A,2));    % size(A,2)=nclass-1
for i =1:p11
    Kernel_sub=zeros(n,m11); 
    Rtestfea=fea_sub((i-1)*m11+1:i*m11,:);
   for jj=1:m
%     if betas(jj)>betas_tol
     kernel_option = [];
     switch lower(KernelTypes{jj})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    Kernel_sub_1 = constructKernel(fea_sub,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(fea_sub,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(fea_sub,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(jj);
                        Kernel_sub_1 = constructKernel(fea_sub,Rtestfea, kernel_option);
                        Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
     end 
        Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
%     end
  end
    testData_no = A'*Kernel_sub;
    testData((i-1)*m11+1:i*m11,:)=testData_no';
end
clear Rtestfea Kernel_sub_1 Kernel_sub
if ntest-m11*p11>0
Kernel_sub=zeros(n,ntest-m11*p11);
Rtestfea=fea_sub(m11*p11+1:ntest,:);
  for jj=1:m
%     if betas(jj)>betas_tol
     kernel_option = [];
     switch lower(KernelTypes{jj})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    Kernel_sub_1 = constructKernel(fea_sub,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(fea_sub,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(fea_sub,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1,KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(jj);
                        Kernel_sub_1 = constructKernel(fea_sub,Rtestfea, kernel_option);
                        Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
    end 
        Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
%     end
  end
testData_no=A'*Kernel_sub;
testData(m11*p11+1:ntest,:)=testData_no';
clear Rtestfea Kernel_sub_1 Kernel_sub testfea
end

% label=litekmeans(testData,nclass,'MaxIter',100,'Replicates',10);
% result(j,:) = ClusteringMeasure(testgnd,label);

time_SR_test(j)=toc(tstart_test);
end %end times

% ave_ACC=mean(result(:,1));    var_ACC=var(result(:,1));
% ave_NMI=mean(result(:,2));    var_NMI=var(result(:,2));
% ave_RI=mean(result(:,3));    var_RI=var(result(:,3));
% ave_traintime_SR=mean(time_SR_train);  var_traintime_SR=var(time_SR_train);
% ave_testtime_SR=mean(time_SR_test);   var_testtime_SR=var(time_SR_test);
% ave_betas=mean(Betas,2);
end

