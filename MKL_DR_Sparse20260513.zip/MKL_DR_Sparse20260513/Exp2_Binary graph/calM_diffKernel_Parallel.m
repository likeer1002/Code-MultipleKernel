function b = calM_diffKernel_Parallel(trainfea,p1)
% ����˾���֮�������Ծ���--����F����
global KernelTypes KernelPostProcessTypes Degrees;
m=length(Degrees);
n=size(trainfea,1);
m1=floor(p1*n);
cols = randperm(n,m1); % uniform sampling without replacement 
Rtrainfea=trainfea(cols,:);

% M = zeros(m);
b=zeros(m,1);
K_sum=zeros(n,m1);
for i =1:m
            % computing i-th sub_kernel
     kernel_option = [];
     switch lower(KernelTypes{i})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok      
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(i);
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(i);
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(i);
                        kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                        kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
     end
 K_sum=K_sum+ kernel_sub;  
end

for j = 1:m

       % computing j-th sub_kernel    
     kernel_option = [];
     switch lower(KernelTypes{j})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(j);
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(j);
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(j);
                        kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                        kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
    end        
 b(j)=trace(kernel_sub'*K_sum)/norm(kernel_sub,'fro')^2;
 b(j)=abs(b(j));
end %end j

% M = (M+M')+eye(m);
clear Rtrainfea kernel_sub 
end