function [betas,b]=UpdateWeight_diffK_Paral_ourKaczmarz_1(betas,trainfea,A,b,D1,W1,tol,max_IT,ReducedDim,p1,betas_tol,gamma,lambda) 
% Updating kernel weights by adding a regularization term to make it sparse
global KernelTypes KernelPostProcessTypes Degrees;
tstart=tic;
n=size(trainfea,1);
m=length(Degrees);
m1=floor(p1*n); 
% Step 1: block randomized kaczmarz algorithm(������У�
% b=sum(M,2);
b=gamma*b/4;  %b=gamma*b;
x0=zeros(n*ReducedDim,1);
x1=zeros(n*ReducedDim,1);
t_1=tic;
hi=floor(m/5);%������
err=1;
IT=1;

while err>tol && IT<max_IT
K_sub=zeros(n*ReducedDim,hi);
% w1=randperm(m,hi); 
w1=randsrc(1,hi,[1:m; betas']);%������ѡ���

for j=1:hi

    kernel_option = [];
     switch lower(KernelTypes{w1(j)})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    cols = randperm(n,m1); % uniform sampling without replacement 
                    Rtrainfea=trainfea(cols,:);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(w1(j));
                    cols = randperm(n,m1); % uniform sampling without replacement 
                    Rtrainfea=trainfea(cols,:);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(w1(j));
                    cols = randperm(n,m1); % uniform sampling without replacement 
                    Rtrainfea=trainfea(cols,:);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(w1(j));
                        cols = randperm(n,m1); % uniform sampling without replacement 
                        Rtrainfea=trainfea(cols,:);
                        C = constructKernel(trainfea,Rtrainfea, kernel_option);
                        C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
     end
        W = C(cols,:);  
        W=max(W,W');% m-by-m intersection matrix
        W=((A'*C)*pinv(W))*C';
        K_sub(:,j)=reshape(W,n*ReducedDim,1);
end  % ���У�ͨ�����У�
% K_sub=K_sub'; % ����

clear Rtrainfea C W
    [U,S,V]=svd(K_sub,'econ'); 
    x1=x0+U*((diag(S).^(-1)).*(V'*(b(w1)-K_sub'*x0)));
    clear U S V K_sub
err=norm(x1-x0)^2/norm(x1)^2;

    x0=x1;
    IT=IT+1;
end
IT
y=x1;
error_1=err;
T_1=toc(t_1)

% Step 2: minres���
t_2=tic;
% if TrueOrFalse
% % AA=2*(L+lambda*D1);
% % AA=kron(AA,eye(ReducedDim));
% % [b,flag,error_2] = minres(AA,-y,1e-2); 
%     L=diag(D1)-W1; % D1 is a column vector
% else
%     L=D1-W1; 
% end
[b,~,~] = minres(@(x)afun_minres(W1,D1,lambda,ReducedDim,n,x),-y,1e-2,50);

T_2=toc(t_2)
clear AA L D1 W1
% Step 3: block randomized extended kaczmarz algorithm(�������(��)��Nystrom��˾������)
t_3=tic;
[betas]=MYBlockREKcol_diffK_ourKaczmarz_1(betas,trainfea,b,A,tol,max_IT,ReducedDim,p1);
T_3=toc(t_3)


betas = quadprog(eye(m,m),-betas,[],[],ones(1,m),1,zeros(m,1),ones(m,1));
betas(betas<betas_tol)=0;
betas = betas/sum(betas);


time=toc(tstart);
end

function y1=afun_minres(W1,D1,lambda,ReducedDim,n,x)
global memusage_2_minres;
X=reshape(x,ReducedDim,n);
a_2 = whos('X');
memusage_2_minres = a_2(1).bytes /(2^20);
%     X=(1+lambda)*(D1.*X')'-X*W1; % D1 is a column vector.
    X=X*W1-lambda*(D1.*X')'; % D1 is a column vector.
% y1=reshape(2*X,ReducedDim*n,1);
y1=reshape(X,ReducedDim*n,1);
clear X 
end
