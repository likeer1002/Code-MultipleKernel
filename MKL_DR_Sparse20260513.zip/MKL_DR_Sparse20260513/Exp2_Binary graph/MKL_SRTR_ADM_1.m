function [A,betas]=MKL_SRTR_ADM_1(KERNELS,D,W,n,nclass,ReducedDim,r,step2,max_IT2,m)
betas=ones(m,1)/m;
% betas_0=zeros(m,1);
it=1;

% while  it<max_IT2 && norm(betas-betas_0,inf)>=1e-2
while  it<max_IT2
%%%-----------Optimizacion of A (projection matrix)--------------
% betas_0=betas;
Kernel=zeros(n,n);
for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);
end
%   d_rk=svd(Kernel.*D.^(1/2),'econ');  %��svd������ֵ��1e-14
%   rk=length(find(d_rk>=1e-14));
rk=rank(Kernel.*D.^(1/2));
  if rk>n-nclass 

 %%%----------------KSR method--------------  %%%
      options = [];
      options.W = W;
      options.ReguAlpha = 0.5;
      options.ReguType = 'Ridge';
      options.ReducedDim = ReducedDim;
      options.Kernel = 1;
      A = KSR_caller(options, Kernel);
%       A=orth(A);
 
  else
     B=(Kernel.*D.^(1/2))'; %D is a column vector
     [U,~,~]=svd(B,'econ');
     U=U(:,end-n+rk+1:end);
%      [U,~,~]=svds(B,n-rk,0);
    BB=Kernel*U;
    BB=BB'*W*BB;
%     norm(BB-BB','fro')
    BB=max(BB,BB');
     [deltas,deltas_D]=eig(BB);
     [~,indx]=sort(diag(deltas_D),'descend');
     deltas=deltas(:,indx);
     deltas=deltas(:,1:ReducedDim);
%      [deltas,~,~]=eigs(@(x)UKWKUtimesx(U,Kernel,W,x),n-rk,ReducedDim,'lm');%����
     A=U*deltas;
%      A=orth(A);
  end
   %%%-----------Optimizing Betas (Kernel weights)--------------
  d_betas=zeros(m,1);
  for i=1:m
     d_betas(i)=trace(2*A'*KERNELS(:,:,i)*(W-r*diag(D))*Kernel*A);  
  end
  betas=betas+step2*d_betas/norm(d_betas);
  
%     cvx_begin
%        variable p(m)
%        minimize(norm(p-betas,2)^2)
%        subject to
%           p'*e==1;
%           p>=0;  
%     cvx_end
%     betas=p;

  betas = quadprog(eye(m,m),-real(betas),[],[],ones(1,m),1,zeros(m,1),ones(m,1));
  betas(betas<1e-6)=0;
  betas = betas/sum(betas);
  it=it+1;
end
%%%-----------SR method-------------- %%% 
%       newfea=[];
%       for i=1:n
%           Ki=KERNELS(:,i,:);
%           Ki=reshape(Ki,n,m);
%           newfea=[newfea,Ki*betas];
%       end
%       options = [];
%       options.W = W;
%       options.gnd = traingnd;
%       options.ReguAlpha = 0.5;
%       options.ReguType = 'Ridge';
%       options.ReducedDim = ReducedDim;
%       A= SR_caller(options, newfea');
% %       A=orth(A);
%%%----------------KSR method--------------  %%%
      options = [];
      options.W = W;
      options.ReguAlpha = 0.5;
      options.ReguType = 'Ridge';
      options.ReducedDim = ReducedDim;
      options.Kernel = 1;
      A = KSR_caller(options, Kernel);
%       A=orth(A);
end
