function y = UKWKUtimesx( U,K,W,x )
%����y=U'*K*W*K*U*x
y=U*x;
y=K*y;
y=W*y;
y=K*y;
y=U'*y;

end

