close all
clear 
clc
%% 12����ͬ�ĺ˾���
times=5;
p=[0.2,0.4,0.6,0.8]';  %ѡ��p��������Ϊѵ����

DataBase='ORL_32x32';     %n=400(ntrain=280)
% DataBase='ORL_64x64';     %n=400(ntrain=280)
% DataBase='YaleB_64x64';   %n=2432(ntrain=1710)
% DataBase='AR_30x40';      %n=2600(ntrain=1900)
% DataBase='sub_USPS';      %n=5000(ntrain=3500)
% DataBase='USPS';             %n=9298(ntrain=)
% DataBase='TDT2';             %n=9394(ntrain=6589)
% DataBase='PIE_32x32';     %n=11560(ntrain=8092)
% DataBase='Facescrub';        %n=22631(ntrain=15956) ��
% DataBase='CIFAR-100';        %n=60000(ntrain=42000)
% DataBase='MNIST';            %n=70000(ntrain=49005)
% DataBase='YouTubeFaceArrange_32x32';  %n=370319(ntrain=259369)


% width=[0.1,0.22,0.46,1,2.15,4.46,10,21.54,46.42,100]';
global KernelTypes KernelPostProcessTypes Degrees;
KernelTypes = {'Linear', 'PolyPlus', 'PolyPlus', 'PolyPlus',... 
    'Polynomial','Polynomial','Polynomial', 'Gaussian', 'Gaussian',...
    'Gaussian', 'Gaussian', 'Gaussian', 'Gaussian','Gaussian'};
% KernelPostProcessTypes = {'Sample-Scale'};
KernelPostProcessTypes = {'MAX'};
% PolynomialDegrees = [2, 4];
% PolyPlusDegrees = [2, 4];
Degrees = [1, 2, 4, 6, 2, 4, 6, 0.01, 0.05, 0.1, 1, 10, 50, 100]; % 12 base kernels


Create_Train_Test_diffp(DataBase,p,times);

%%-------------MKL_DR method------------------%%
%     disp('Starting to Compute MKL_DR...')
%     step1=1; step2=0.5; %length of step
%     max_IT1=5;  max_IT2=5;
%     [ave_accuracy_1,var_accuracy_1,ave_time_SRTR_1,var_time_SRTR_1,ave_betas_1]=MKL_DR(times,DataBase,width,step1,max_IT1,step2,max_IT2);
%     disp(['MKL_DR����������ʱ��:',num2str(ave_time_DR_1)]);

%%-------------MKL_SRTR method------------------%%
%     disp('Starting to Compute MKL_SRTR...')
%     step1=1; step2=0.5; %length of step
%     max_IT1=5;  max_IT2=5;
%     [ave_accuracy_1,var_accuracy_1,ave_time_SRTR_1,var_time_SRTR_1,ave_betas_1]=MKL_SRTR_1(times,DataBase,width,step1,max_IT1,step2,max_IT2);
%     disp(['MKL_SRTR����������ʱ��:',num2str(ave_time_SRTR_1)]);

%%-------------Our method--Computing A by Kaczmarz method------------------%%
    % disp('Starting to Compute OurMethod...')
    % tol1=1e-2;  max_IT1=20; 
    % tol2=1e-2;  max_IT2=20;
    % max_IT=5;
    % [meanErr_A,meanErr_betas,ave_accuracy,var_accuracy,ave_time_OURS,var_time_OURS,ave_betas]=OurMethod(times,DataBase,width,tol1,max_IT1,tol2,max_IT2,max_IT);
    % disp(['Our Method������ʱ��:',num2str(ave_time_OURS)]);
% %%--------------Our method--Computing A by Nystrom method-----------------%%
%     disp('Starting to Compute OurMethod...')
%     tol2=1e-2;  max_IT2=20;
%     max_IT=5;
%     p1=0.1;   %Nystrom�еĲ�������
%     [ave_accuracy,var_accuracy,ave_time_OURS,var_time_OURS,ave_betas]=OurMethod_3(times,DataBase,width,tol2,max_IT2,max_IT,p1);
%     sum(ave_betas)
%     disp(['Our Method������ʱ��:',num2str(ave_time_OURS)]);

%%--------------Our Sparse method--Computing betas -----------------%%
    memusage=zeros(length(p),1);
    error_1=zeros(length(p),1);
    error_2=zeros(length(p),1);
    error_3=zeros(length(p),1);
    ave_Saccuracy=zeros(length(p),1);
    ave_Straintime_OURS=zeros(length(p),1);
    ave_Stesttime_OURS=zeros(length(p),1);
    ave_Sbetas=zeros(length(Degrees),length(p));  
for i=1:length(p)
    disp('Starting to Compute OurSparseMethod...')
    alg='OurSparseMethod_diffKernel';
    tol2=1e-2;  max_IT2=20;
        betas_tol=0.07;%1e-6
%     betas_tol=1/length(Degrees)-0.01;%1e-6
    max_IT=5;
    TrueOrFalse=1;
    
    step1=1e-1;% length of step used to update Lagrange multiplier
    p1=0.3;   %Nystrom�еĲ�������
%     gamma=[2e-2,2e-1,2,2e1,2e2,2e3]';  % a parameter to trade off the clustering cost function and the regularization term.
    gamma=0.2;
    lambda=0.1;   % Lagrange multiplier
%     [error_1,error_2,error_3,ave_Saccuracy,var_Saccuracy,ave_Stime_OURS,var_Stime_OURS,ave_Sbetas]=OurSparseMethod_1(times,DataBase,width,tol2,max_IT2,max_IT,p1,betas_tol,gamma,lambda,step1);
%     error_1=zeros(length(gamma),1);
%     error_2=zeros(length(gamma),1);
%     error_3=zeros(length(gamma),1);
%     ave_Saccuracy=zeros(length(gamma),1);
%     ave_Straintime_OURS=zeros(length(gamma),1);
%     ave_Stesttime_OURS=zeros(length(gamma),1);
%     ave_Sbetas=zeros(length(Degrees),length(gamma));        
       [BIG_betas,memusage(i),error_1(i),error_2(i),error_3(i),ave_Saccuracy(i),var_Saccuracy,ave_Straintime_OURS(i),var_Straintime_OURS,ave_Stesttime_OURS(i),var_Stesttime_OURS,ave_Sbetas(:,i)]...
           =OurSparseMethod_1_diffKernel(times,DataBase,tol2,max_IT2,max_IT,p1,betas_tol,gamma,lambda,step1,TrueOrFalse,p(i));
end
    filename = strcat(alg,'+',DataBase,'+',num2str(p1),'+',num2str(betas_tol),'+','multiplep','.mat'); % �洢���ļ���
    save(filename,'Degrees','ave_Saccuracy','ave_Straintime_OURS','ave_Stesttime_OURS','ave_Sbetas','memusage','-v7.3');
    disp(['Our Sparse Method������ʱ��:',num2str(ave_Straintime_OURS(length(p)))]);
%     % plot weights ,i.e., betas
%     [~,accidx]=max(ave_Saccuracy);
%     figure
%     bar(ave_Sbetas(:,accidx))
%     file = strcat(DataBase,'\','Train\',int2str(1),'.mat');
%     load(file,'traingnd');
%     title(strcat(DataBase,'(with n=',num2str(length(traingnd)),')'));
%     xlabel('Kernel index');
%     ylabel('Weights');


    