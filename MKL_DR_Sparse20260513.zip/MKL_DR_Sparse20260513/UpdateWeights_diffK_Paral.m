function [betas,b,error_1,error_2,error_3]=UpdateWeights_diffK_Paral...
    (trainfea,A,b,D1,W1,tol,max_IT,ReducedDim,p1,betas_tol,gamma,lambda,TrueOrFalse) 
% Updating kernel weights by adding a regularization term to make it sparse
global KernelTypes KernelPostProcessTypes Degrees;
tstart=tic;
n=size(trainfea,1);
m=length(Degrees);
m1=floor(p1*n);
% Step 1: block randomized kaczmarz algorithm(������У�
% b=sum(M,2);
b=gamma*b;
x0=zeros(n*ReducedDim,1);
x1=zeros(n*ReducedDim,1);
t_1=tic;
hi=floor(m/5);%������
err=1;
IT=1;

while err>tol && IT<max_IT
w1=randperm(m,hi);  
K_sub=zeros(n*ReducedDim,hi);
for j=1:hi
    kernel_option = [];
     switch lower(KernelTypes{w1(j)})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
            for iPost = KernelPostProcessTypes
                    cols = randperm(n,m1); % uniform sampling without replacement 
                    Rtrainfea=trainfea(cols,:);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, iPost{1});%#ok
            end
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(w1(j));
                for iPost = KernelPostProcessTypes
                    cols = randperm(n,m1); % uniform sampling without replacement 
                    Rtrainfea=trainfea(cols,:);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, iPost{1});%#ok
                end
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(w1(j));
                for iPost = KernelPostProcessTypes
                    cols = randperm(n,m1); % uniform sampling without replacement 
                    Rtrainfea=trainfea(cols,:);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, iPost{1});%#ok
                end
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(w1(j));
                for iPost = KernelPostProcessTypes
                        cols = randperm(n,m1); % uniform sampling without replacement 
                        Rtrainfea=trainfea(cols,:);
                        C = constructKernel(trainfea,Rtrainfea, kernel_option);
                        C = KernelNormalize(C, iPost{1});%#ok
                end
        otherwise
            error('KernelType does not exist!');
     end
        W = C(cols,:);  
        W=max(W,W');% m-by-m intersection matrix
    K_sub(:,j)=reshape(((A'*C)*pinv(W))*C',n*ReducedDim,1);
end  % ���У�ͨ�����У�
% K_sub=K_sub'; % ����
clear Rtrainfea C W
    [U,S,V]=svd(K_sub,'econ'); 
    x1=x0+U*(diag(diag(S).^(-1))*(V'*(b(w1)-K_sub'*x0)));
    clear U S V K_sub
err=norm(x1-x0)^2/norm(x1)^2;

    x0=x1;
    IT=IT+1;
end
IT
y=x1;
error_1=err;
T_1=toc(t_1)

% Step 2: minres���
t_2=tic;
% if TrueOrFalse
% % AA=2*(L+lambda*D1);
% % AA=kron(AA,eye(ReducedDim));
% % [b,flag,error_2] = minres(AA,-y,1e-2); 
%     L=diag(D1)-W1; % D1 is a column vector
% else
%     L=D1-W1; 
% end
[b,flag,error_2] = minres(@(x)afun_minres(W1,D1,lambda,ReducedDim,n,x,TrueOrFalse),-y,1e-2);

T_2=toc(t_2)
clear AA L D1 W1
% Step 3: block randomized extended kaczmarz algorithm(�������(��)��Nystrom��˾������)
t_3=tic;
[betas,error_3,IT]=MYBlockREKcol_betas_0_diffKernel(trainfea,b,A,tol,max_IT,ReducedDim,p1);
T_3=toc(t_3)

t_4=tic;
betas = quadprog(eye(m,m),-betas,[],[],ones(1,m),1,zeros(m,1),ones(m,1));
betas(betas<betas_tol)=0;
betas = betas/sum(betas);
T_4=toc(t_4)

time=toc(tstart);
end

function y1=afun_minres(W1,D1,lambda,ReducedDim,n,x,TrueOrFalse)
global memusage_2_minres;
X=reshape(x,ReducedDim,n);
a_2 = whos('X');
memusage_2_minres = a_2(1).bytes /(2^20);
if TrueOrFalse
  X=X*(diag(D1)-W1)+lambda*(X'.*D1)'; % D1 is a column vector.
else
  X=X*((lambda+1)*D1-W1);
end
y1=reshape(2*X,ReducedDim*n,1);
clear X L1
end
