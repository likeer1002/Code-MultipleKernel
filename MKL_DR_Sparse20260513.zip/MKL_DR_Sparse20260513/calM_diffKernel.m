function M = calM_diffKernel(trainfea,p1)
% ����˾���֮�������Ծ���--����2����
global KernelTypes KernelPostProcessTypes Degrees;
m=length(Degrees);
n=size(trainfea,1);
m1=floor(p1*n);
cols = randperm(n,m1); % uniform sampling without replacement 
Rtrainfea=trainfea(cols,:);

M = zeros(m);
for i =1:m-1
            % computing i-th sub_kernel
     kernel_option = [];
     switch lower(KernelTypes{i})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
            for iPost = KernelPostProcessTypes
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, iPost{1});%#ok
                    [Qi,~]=qr(kernel_sub,0); 
            end
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(i);
                for iPost = KernelPostProcessTypes
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, iPost{1});%#ok
                    [Qi,~]=qr(kernel_sub,0); 
                end
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(i);
                for iPost = KernelPostProcessTypes
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, iPost{1});%#ok
                    [Qi,~]=qr(kernel_sub,0); 
                end
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(i);
                for iPost = KernelPostProcessTypes
                        kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                        kernel_sub = KernelNormalize(kernel_sub, iPost{1});%#ok
                        [Qi,~]=qr(kernel_sub,0); 
                end
        otherwise
            error('KernelType does not exist!');
    end
for j = i+1:m

       % computing j-th sub_kernel    
     kernel_option = [];
     switch lower(KernelTypes{j})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
            for iPost = KernelPostProcessTypes
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, iPost{1});%#ok
                    [Qj,~]=qr(kernel_sub,0); 
            end
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(j);
                for iPost = KernelPostProcessTypes
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, iPost{1});%#ok
                    [Qj,~]=qr(kernel_sub,0); 
                end
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(j);
                for iPost = KernelPostProcessTypes
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, iPost{1});%#ok
                    [Qj,~]=qr(kernel_sub,0); 
                end
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(j);
                for iPost = KernelPostProcessTypes
                        kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                        kernel_sub = KernelNormalize(kernel_sub, iPost{1});%#ok
                        [Qj,~]=qr(kernel_sub,0); 
                end
        otherwise
            error('KernelType does not exist!');
    end        
        M(i,j) = norm(Qj'*Qi);
end %end j
end %end i

M = (M+M')+eye(m);
clear Rtrainfea kernel_sub Qi Qj
end