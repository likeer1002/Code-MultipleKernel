function [betas,b,error_1,error_2,error_3]=UpdateWeights_1...
    (trainfea,A,M,D1,W1,tol,max_IT,ReducedDim,width,p1,betas_tol,gamma,lambda,TrueOrFalse) 
% Updating kernel weights by adding a regularization term to make it sparse
tstart=tic;
n=size(trainfea,1);
m=length(width);
m1=floor(p1*n);
% Step 1: block randomized kaczmarz algorithm(������У�
b=sum(M,2);
b=gamma*b;
x0=zeros(n*ReducedDim,1);
x1=zeros(n*ReducedDim,1);
t_1=tic;
hi=floor(m/5);%������
err=1;
IT=1;

while err>tol && IT<max_IT
w1=randperm(m,hi);  
K_sub=zeros(n*ReducedDim,hi);
for j=1:hi
        options=[];
        options.KernelType = 'Gaussian';
        options.t=width(w1(j));
        cols = randperm(n,m1); % uniform sampling without replacement 
        Rtrainfea=trainfea(cols,:);
        C= constructKernel(trainfea,Rtrainfea,options);
        W = C(cols,:);  
        W=max(W,W');% m-by-m intersection matrix
    K_sub(:,j)=reshape(((A'*C)*pinv(W))*C',n*ReducedDim,1);
end  % ���У�ͨ�����У�
K_sub=K_sub'; % ����
clear Rtrainfea C W
    [U,S,V]=svd(K_sub','econ'); 
    x1=x0+U*(diag(diag(S).^(-1))*(V'*(b(w1)-K_sub*x0)));
    clear U S V K_sub
err=norm(x1-x0)^2/norm(x1)^2;

    x0=x1;
    IT=IT+1;
end
y=x1;
error_1=err;
T_1=toc(t_1)

% Step 2: minres���
t_2=tic;
if TrueOrFalse
% AA=2*(L+lambda*D1);
% AA=kron(AA,eye(ReducedDim));
% [b,flag,error_2] = minres(AA,-y,1e-2); 
    L=diag(D1)-W1; % D1 is a column vector
else
    L=D1-W1; 
end
[b,flag,error_2] = minres(@(x)afun_minres(L,D1,lambda,ReducedDim,n,x,TrueOrFalse),-y,1e-2);

T_2=toc(t_2)
clear AA L D1 W1
% Step 3: block randomized extended kaczmarz algorithm(�������(��)��Nystrom��˾������)
t_3=tic;
[betas,error_3,IT]=MYBlockREKcol_betas_0(trainfea,b,A,tol,max_IT,ReducedDim,width,p1);
T_3=toc(t_3)

t_4=tic;
betas = quadprog(eye(m,m),-betas,[],[],ones(1,m),1,zeros(m,1),ones(m,1));
betas(betas<betas_tol)=0;
betas = betas/sum(betas);
T_4=toc(t_4)

time=toc(tstart);
end

function y1=afun_minres(L,D1,lambda,ReducedDim,n,x,TrueOrFalse)

X=reshape(x,ReducedDim,n);
if TrueOrFalse
  L1=X*L+lambda*(X'.*D1)'; % D1 is a column vector.
else
  L1=X*(L+lambda*D1);
end
y1=reshape(2*L1,ReducedDim*n,1);
clear X L1

end
