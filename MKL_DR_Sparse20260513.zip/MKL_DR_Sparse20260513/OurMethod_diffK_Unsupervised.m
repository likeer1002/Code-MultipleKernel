function [ave_ACC,var_ACC,ave_NMI,var_NMI,ave_RI,var_RI,ave_traintime_OURS,var_traintime_OURS,ave_testtime_OURS,var_testtime_OURS,ave_betas]...
    =OurMethod_diffK_Unsupervised(times,DataBase,tol2,max_IT2,max_IT,p1,p)
%  Our method--Computing A by Nystrom method--�����ݣ����Թ��̣�
global KernelTypes KernelPostProcessTypes Degrees;
time_OURS_train=zeros(times,1);
time_OURS_test=zeros(times,1);
m=length(Degrees);
Betas=zeros(m,times);

for j = 1:times
tstart=tic;
     betas=ones(m,1)/m;
     betas_0=zeros(m,1);
     file = strcat('un','_',DataBase,'\','Train\',num2str(p),'\',int2str(j),'.mat');
     load(file, 'trainfea','traingnd');
%      eval(['load ' DataBase, '\','Train\',int2str(j),'.mat']); 
     nclass=length(unique(traingnd));  %�ܹ��������
     ReducedDim=nclass-1;
     n=size(trainfea,1);  %ѵ������������
     
      options = [];
      options.NeighborMode = 'KNN';
      options.k = 15;
      options.WeightMode = 'Binary';
W = constructW(trainfea,options); %%% sparse Affinity matrix
D=full(sum(W,2));   %Column vector
% t_1=tic;
% W=kron(W,eye(ReducedDim,ReducedDim));
% D=D.^(-1);
% D=diag(D); % Diagonal matrix  D
% D_inverse=kron(D,eye(ReducedDim,ReducedDim));
% t_11=toc(t_1) 
 t_2=tic;
Y = Eigenmap(W,ReducedDim);
t_22=toc(t_2)

IT=1;
while IT<max_IT  && norm(betas-betas_0,inf)>=1e-2
 %%%-----------Optimizacion of A (projection matrix)-------------- 
 betas_0=betas;
 

t_3=tic;
% [A,err_A(j),IT_A(j),time_Decom_A(j)]=MYBlockREKcol_multiple_A(trainfea,Y,betas,tol1,max_IT1,width); 
% A=orth(A);
A=Nystrom_A_diffKernel(trainfea,Y,betas,p1);
t_33=toc(t_3)
%%%-----------Optimizing Betas (Kernel weights)--------------
t_4=tic;
y= Eigenmap(W,1);
y=sparse(kron(y,eye(ReducedDim,1)));
t_44=toc(t_4)

% [betas,err_betas(j),IT_betas(j),time_Decom_betas(j)]=MYBlockREKcol_betas(trainfea,y,A,tol2,max_IT2,ReducedDim,width); 
% [betas,time_Decom_betas(j)]=QRComputing_betas_1(trainfea,y,A,ReducedDim,width,p1); 
t_5=tic;
[betas,err_betas(j),IT_betas(j),time_Decom_betas(j)]=MYBlockREKcol_diffK_1_ourKaczmarz(betas,trainfea,y,A,tol2,max_IT2,ReducedDim,p1); 

t_55=toc(t_5)


IT=IT+1;
end %\end while
time_OURS_train(j)=toc(tstart);
Betas(:,j)=betas;
%%%----�����棺m���˾���KERNELS�Լ�һ��mixed�˾���Kernel-------%%%
%%%--------- Data projected in the learned representation space-----------
tstart_test=tic;


%%%-----------------------------------------------%%%
% load(file, 'trainfea','traingnd');
% n=size(trainfea,1);
m11=floor(p1*n);  %�˾���n*ntest�����в����У�ÿ�βɵ�����  
p11=floor(1/p1);  %�˾���n*ntest�����в����У��ɵĴ���  
trainData = zeros(n,size(A,2));    % size(A,2)=nclass-1
for i =1:p11
    Kernel_sub=zeros(n,m11); 
    Rtrainfea=trainfea((i-1)*m11+1:i*m11,:);
   for jj=1:m
     kernel_option = [];
     switch lower(KernelTypes{jj})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    Kernel_sub_1 = constructKernel(trainfea,Rtrainfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtrainfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtrainfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(jj);
                        Kernel_sub_1 = constructKernel(trainfea,Rtrainfea, kernel_option);
                        Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
    end 
        Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
  end
    trainData_no = A'*Kernel_sub;
    trainData((i-1)*m11+1:i*m11,:)=trainData_no';
end
clear Rtrainfea Kernel_sub_1 Kernel_sub
if n-m11*p11>0
Kernel_sub=zeros(n,n-m11*p11);
Rtrainfea=trainfea(m11*p11+1:n,:);
  for jj=1:m
     kernel_option = [];
     switch lower(KernelTypes{jj})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    Kernel_sub_1 = constructKernel(trainfea,Rtrainfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtrainfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1,KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtrainfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1,KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(jj);
                        Kernel_sub_1 = constructKernel(trainfea,Rtrainfea, kernel_option);
                        Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
    end 
        Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
  end
trainData_no=A'*Kernel_sub;
trainData(m11*p11+1:n,:)=trainData_no';
clear Rtrainfea Kernel_sub_1 Kernel_sub trainfea
end

label=litekmeans(trainData,nclass,'MaxIter',100,'Replicates',10);
result(j,:) = ClusteringMeasure(traingnd,label);

time_OURS_test(j)=toc(tstart_test);
% model_linear = svmtrain(traingnd, trainData, '-t 0');
% [~, accuracy_1, ~] = svmpredict(testgnd, testData, model_linear);
% accuracy(j)=accuracy_1(1);
end%\end times

ave_ACC=mean(result(:,1));    var_ACC=var(result(:,1));
ave_NMI=mean(result(:,2));    var_NMI=var(result(:,2));
ave_RI=mean(result(:,3));    var_RI=var(result(:,3));
ave_traintime_OURS=mean(time_OURS_train);  var_traintime_OURS=var(time_OURS_train);
ave_testtime_OURS=mean(time_OURS_test);  var_testtime_OURS=var(time_OURS_test);
ave_betas=mean(Betas,2);
% memusage=memusage_1;
end
