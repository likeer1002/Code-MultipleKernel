function [A,betas]=MKL_TR_ADM(KERNELS,D,W,n,ReducedDim,r,step2,max_IT2,m,lambda)
% betas_0=zeros(m,1);
betas=ones(m,1)/m;

it=1;

% while  it<max_IT2 && norm(betas-betas_0,inf)>=1e-2
while  it<max_IT2
%%%-----------Optimizacion of A (projection matrix)--------------
% betas_0=betas;
Kernel=zeros(n,n);
for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);
end
% pinv_Kernel=pinv(Kernel);
% [Q,deltas_D]=eig(Kernel*(W-r*diag(D))-r*lambda*pinv_Kernel);
% [~,indx]=sort(diag(deltas_D),'descend');
% Q=Q(:,indx);

[A,deltas_D]=eig(Kernel*(W-r*diag(D))*Kernel-r*lambda*eye(n),Kernel+1e-6*speye(n));
[~,indx]=sort(diag(deltas_D),'descend');
A=A(:,indx);
Q=Kernel*A+1e-6*A;

   %%%-----------Optimizing Betas (Kernel weights)--------------
  d_betas=zeros(m,1);
  pinv_Kernel=pinv(Kernel);
  pro_K=Q'*pinv_Kernel;
  for i=1:m
     d_betas(i)=trace(Q'*KERNELS(:,:,i)*(W-r*diag(D))*Q)+r*lambda*trace(pro_K*KERNELS(:,:,i)*pro_K');  
  end
  betas=betas+step2*d_betas/norm(d_betas);

  betas = quadprog(eye(m,m),-betas,[],[],ones(1,m),1,zeros(m,1),ones(m,1));
  betas(betas<1e-6)=0;
  betas = betas/sum(betas);
  it=it+1;
end
Kernel=zeros(n,n);
for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);
end
[A,deltas_D]=eig(Kernel*(W-r*diag(D))*Kernel-r*lambda*eye(n),Kernel+1e-6*speye(n));
[~,indx]=sort(diag(deltas_D),'descend');
A=A(:,indx(1:ReducedDim));
end
