% Randomized algorithm for SVD 
%
% Input: k is the number for low-rank approximation
%        q: do q times matrix-vector products
%
function [U,S,V]=randomizedSVD(A,k,q)
n=size(A,2);
Y=randn(n,k);
%
Y=A*Y;

if q>0
for i=1:q
    Y=A*(A'*Y);
end
end
%
[Y,~]=qr(Y,0); % the columns of Y approximate range(A)
%
U=Y'*A;       %U is k-by-n 
[U,S,V]=svd(U,'econ'); %U is k-by-k
U=Y*U;          %U is m-by-k
clear Y
% A~=U*S*V';
% erro=norm(U*(U'*A)-A,'fro')/norm(A,'fro')