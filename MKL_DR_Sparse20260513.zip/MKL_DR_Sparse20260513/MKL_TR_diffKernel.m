function [ave_accuracy,var_accuracy,ave_traintime_TR,var_traintime_TR,ave_testtime_TR,var_testtime_TR,ave_betas]...
    =MKL_TR_diffKernel(times,DataBase,step1,max_IT1,step2,max_IT2,p)
%  ��MKL_TR����Multiple kernel dimensionality reduction via spectral regression and trace ratio maximization
global KernelTypes KernelPostProcessTypes Degrees;
accuracy=zeros(times,1);
time_TR_train=zeros(times,1);
time_TR_test=zeros(times,1);
m=length(Degrees);
Betas=zeros(m,times);
lambda=1e-4;
for j = 1:times
tstart=tic;
     file = strcat(DataBase,'\','Train\',num2str(p),'\',int2str(j),'.mat');
%      file = strcat(DataBase,'\','Train\',int2str(j),'.mat');

     load(file, 'trainfea','traingnd');
%      eval(['load ' DataBase, '\','Train\',int2str(j),'.mat']); 
     nclass=length(unique(traingnd));  %�ܹ��������
     ReducedDim=nclass-1;
     n=size(trainfea,1);  %ѵ������������

%       options = [];
%       options.NeighborMode = 'KNN';
%       options.k = 5;
%       options.WeightMode = 'HeatKernel';
      options = [];
      options.NeighborMode = 'Supervised';
      options.gnd = traingnd;
      options.bLDA = 1;
%       options.WeightMode = 'HeatKernel';    
W = constructW(trainfea,options); %%% sparse Affinity matrix
D=full(sum(W,2));   %Column vector
% D=sparse(diag(D));   % Diagonal matrix  D
KERNELS=zeros(n,n,m);
for i=1:m
    kernel_option = [];
     switch lower(KernelTypes{i})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
            for iPost = KernelPostProcessTypes
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, iPost{1});%#ok
            end
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(i);
                for iPost = KernelPostProcessTypes
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, iPost{1});%#ok
                end
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(i);
                for iPost = KernelPostProcessTypes
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, iPost{1});%#ok
                end
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(i);
                for iPost = KernelPostProcessTypes
                  kernel=constructKernel(trainfea,[],kernel_option);
                  kernel = KernelNormalize(kernel, iPost{1});%#ok
                end
        otherwise
            error('KernelType does not exist!');
     end
KERNELS(:,:,i)=kernel;
end

r=1;
f_r=1;
it=1;

while f_r~=0 && it<max_IT1
    [A,betas]=MKL_TR_ADM(KERNELS,D,W,n,ReducedDim,r,step2,max_IT2,m,lambda); %Alternating projections
    Kernel=zeros(n,n);
  for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
  
% %      [~,deltas_D]=eig(Kernel*(W-r*diag(D))*Kernel-r*lambda*eye(n));
%     [~,deltas_D]=eig(Kernel*(W-r*diag(D))*Kernel-r*lambda*eye(n),Kernel+1e-6*eye(n));
%     [deltas_D,~]=sort(diag(deltas_D),'descend');
%     f_r=sum(deltas_D(1:ReducedDim));
    f_r_1=Kernel*A;
    f_r=trace(f_r_1'*((W-r*diag(D))*f_r_1))-r*lambda*norm(A,'fro')^2;
    C=D.^(1/2).*f_r_1;
    d_f_r=-norm(C,'fro')^2-lambda*norm(A,'fro')^2;
    r=r-step1*f_r/d_f_r;

  it=it+1;
end   %end while
time_TR_train(j)=toc(tstart);
Betas(:,j)=betas;
 %%%--------- Data projected in the learned representation space-----------
tstart_test=tic;
    Kernel=zeros(n,n);
  for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end

trainData = zeros(n,size(A,2));    % size(A,2)=nclass-1
for i =1:n
    trainData(i,:) = Kernel(i,:)*A;
end
load(file, 'testfea','testgnd');
ntest=size(testfea,1);
KERNELS_test=zeros(n,ntest,m);
for i=1:m
    kernel_option = [];
     switch lower(KernelTypes{i})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
            for iPost = KernelPostProcessTypes
                kernel=constructKernel(trainfea,testfea,kernel_option);
                kernel = KernelNormalize(kernel, iPost{1});%#ok
            end
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(i);
                for iPost = KernelPostProcessTypes
                kernel=constructKernel(trainfea,testfea,kernel_option);
                kernel = KernelNormalize(kernel, iPost{1});%#ok
                end
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(i);
                for iPost = KernelPostProcessTypes
                kernel=constructKernel(trainfea,testfea,kernel_option);
                kernel = KernelNormalize(kernel, iPost{1});%#ok
                end
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(i);
                for iPost = KernelPostProcessTypes
                kernel=constructKernel(trainfea,testfea,kernel_option);
                kernel = KernelNormalize(kernel, iPost{1});%#ok
                end
        otherwise
            error('KernelType does not exist!');
     end
KERNELS_test(:,:,i)=kernel;
end
    Kernel_test=zeros(n,ntest);
  for i=1:m
    Kernel_test=Kernel_test+betas(i)*KERNELS_test(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
testData = zeros(ntest,size(A,2));    % size(A,2)=nclass-1
for i =1:ntest
     testData_no= A'*Kernel_test(:,i);
     testData(i,:)=testData_no';
end
accuracy(j)=NN(trainData,testData,traingnd,testgnd);
time_TR_test(j)=toc(tstart_test);
end %end times
ave_accuracy=mean(accuracy);    var_accuracy=var(accuracy);
ave_traintime_TR=mean(time_TR_train);  var_traintime_TR=var(time_TR_train);
ave_testtime_TR=mean(time_TR_test);   var_testtime_TR=var(time_TR_test);
ave_betas=mean(Betas,2);
end

