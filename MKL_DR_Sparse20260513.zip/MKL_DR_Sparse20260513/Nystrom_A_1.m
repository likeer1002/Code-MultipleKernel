function A=Nystrom_A_1(trainfea,Y,betas,width,p1,betas_tol)
m=length(width);
n=size(trainfea,1);
m1=floor(p1*n);
k=m1-10; 
idx = randperm(n); % uniform sampling without replacement 
cols = idx(1:m1);    % m columns indexes
Rtrainfea=trainfea(cols,:);
%%%--------computing some columns,i.e., C-------%%%%%

C=zeros(n,m1);
for j=1:m
    if betas(j)>betas_tol
        options=[];
        options.KernelType = 'Gaussian';
        options.t=width(j);
        KERNELS_sub= constructKernel(trainfea,Rtrainfea,options);
        C=C+betas(j)*KERNELS_sub;
    end
end
clear KERNELS_sub trainfea Rtrainfea
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
W = C(cols,:);  
W=max(W,W');% m-by-m intersection matrix
[Q,R] = qr (C,0); % thin QR decomposition of matrix C
W =R * pinv(W) * R'; 
W=max(W,W');
[V,D] = svd(W,'econ');
V=V(:,1:k);
D=D(1:k,1:k);
% DD=diag(D);
V=Q*V;
A=V*(diag(diag(D).^(-1))*(V'*Y));
%%%-------����Nystrom�����Ľ���Ч��---------%%%
% K_app=V*D*V';
% KERNELS=zeros(n,n,m);
% for i=1:m
%     options=[];
%     options.KernelType = 'Gaussian';
%     options.t=width(i);
%    KERNELS(:,:,i) = constructKernel(trainfea,[],options);
% end
% Kernel=zeros(n,n);
% for j=1:m
%     Kernel=Kernel+betas(j)*KERNELS(:,:,j);
% end
% err = norm ( Kernel-K_app, 'fro')/norm(Kernel,'fro');
% err_1=norm(Kernel*A-Y,'fro');
% err_2=norm(Kernel*A-Y,'fro')/norm(Y,'fro');
end


