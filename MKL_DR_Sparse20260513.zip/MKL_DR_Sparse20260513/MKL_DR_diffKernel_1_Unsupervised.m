function [ave_ACC,var_ACC,ave_NMI,var_NMI,ave_RI,var_RI,ave_traintime_DR,var_traintime_DR,ave_testtime_DR,var_testtime_DR,ave_betas]...
    =MKL_DR_diffKernel_1_Unsupervised(times,DataBase,max_IT1,p1,p)
%  ��MKL_DR����Multiple kernel dimensionality reduction via spectral regression and trace ratio maximization
global KernelTypes KernelPostProcessTypes Degrees;
time_DR_train=zeros(times,1);
time_DR_test=zeros(times,1);
m=length(Degrees);
Betas=zeros(m,times);
for j = 1:times
tstart=tic;
     file = strcat('un','_',DataBase,'\','Train\',num2str(p),'\',int2str(j),'.mat');
%      file = strcat(DataBase,'\','Train\',int2str(j),'.mat');

     load(file, 'trainfea','traingnd');
%      eval(['load ' DataBase, '\','Train\',int2str(j),'.mat']); 
     nclass=length(unique(traingnd));  %�ܹ��������
     ReducedDim=nclass-1;
     n=size(trainfea,1);  %ѵ������������

      options = [];
      options.NeighborMode = 'KNN';
      options.k = 15;
      options.WeightMode = 'Binary';
W = constructW(trainfea,options); %%% sparse Affinity matrix
D=full(sum(W,2));   %Column vector
% D=sparse(diag(D));   % Diagonal matrix  D
t_1=tic;
KERNELS=zeros(n,n,m);
for i=1:m
    kernel_option = [];
     switch lower(KernelTypes{i})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
            for iPost = KernelPostProcessTypes
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
            end
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(i);
                for iPost = KernelPostProcessTypes
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
                end
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(i);
                for iPost = KernelPostProcessTypes
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
                end
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(i);
                for iPost = KernelPostProcessTypes
                  kernel=constructKernel(trainfea,[],kernel_option);
                  kernel = KernelNormalize(kernel,KernelPostProcessTypes);%#ok
                end
        otherwise
            error('KernelType does not exist!');
     end
KERNELS(:,:,i)=kernel;
end

t1=toc(t_1)
it=1;
betas=ones(m,1)/m;
while it<max_IT1
    %Computine A
t_2=tic;
    Kernel=zeros(n,n);
  for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
t2=toc(t_2)
t_3=tic;
S_Wbetas=zeros(n,n);
for ii=1:n-1
    for jj=ii+1:n  
      sub=Kernel(:,ii)-Kernel(:,jj);
      S_Wbetas=S_Wbetas+W(ii,jj)*(sub*sub');  
    end
end
S_Wbetas=2*S_Wbetas;
t3=toc(t_3) 
t_4=tic;
% S_Dbetas=zeros(n,n);
% for ii=1:n 
%       S_Dbetas=S_Dbetas+D(ii)*Kernel(:,ii)*(Kernel(:,ii))';  
% end
S_Dbetas=Kernel*(D.*Kernel');
t4=toc(t_4)
t_5=tic;
[A,S_D]=eig(S_Wbetas,S_Dbetas);
[~,indx]=sort(diag(S_D),'ascend');
A=A(:,indx(1:ReducedDim));
t5=toc(t_5)  
  %Computing betas
t_6=tic;
  S_WA=zeros(m,m);
  S_DA=zeros(m,m);
  for ii=1:n-1
      K_i=reshape(KERNELS(:,ii,:),n,m);
      for jj=i+1:n
         K_j=reshape(KERNELS(:,jj,:),n,m);
         BB=(K_i-K_j)'*A;
         S_WA=S_WA+W(ii,jj)*(BB*BB');
      end
      BB=K_i'*A;
      S_DA=S_DA+D(ii)*(BB*BB');
  end
  S_WA=2*S_WA;
  K_i=reshape(KERNELS(:,n,:),n,m);
  BB=K_i'*A;
  S_DA=S_DA+D(n)*(BB*BB');
t6=toc(t_6)  
  %sdpt3���������
  
%   blk{1,1}='s';
%   blk{2,1}='s';
%   blk{1,2}=1;
%   blk{2,2}=m;
%   At{1,1}=0;
%   At{2,1}=S_DA;
%   C{1}=0;
%   C{2}=S_WA;
%   b=1;
t_7=tic;
  blk{1,1}='s';
  blk{1,2}=m+1;
  At{1,1}=blkdiag(0,S_DA);
  C{1}=blkdiag(0,S_WA);
  b=1; 
%   OPTIONS.vers = vers;
OPTIONS=[];
  [X0,y0,Z0] = infeaspt(blk,At,C,b);
  [~,T,~,~,~,~] = sdpt3(blk,At,C,b,OPTIONS,X0,y0,Z0);
  save('T.mat','T');
t7=toc(t_7) 
%   betas1=real(T{2});
%   betas=betas1(:,1);
  betas1=full(real(T{1}));
  betas1(1,:)=[];
  betas=betas1(:,1);

  betas = quadprog(eye(m,m),-betas,[],[],ones(1,m),1,zeros(m,1),ones(m,1));
  betas(betas<1e-6)=0;
  betas = betas/sum(betas);
  it=it+1;
end   %end while
time_DR_train(j)=toc(tstart);
Betas(:,j)=betas;

 %%%--------- Data projected in the learned representation space-----------
tstart_test=tic;

%%%--------------------�޼ල������---------------------------%%%
%�޼ලû��ѵ����, �һ��˾��������ʽ�γɲ��洢������ֱ�ӵ��� KERNELS(:,:,i)=kernel;
Kernel=zeros(n,n);
for jj=1:m
    Kernel=Kernel+betas(jj)*KERNELS(:,:,jj);  %The mixed kernel,
end
trainData = A'*Kernel;
trainData=trainData';
label=litekmeans(trainData,nclass,'MaxIter',100,'Replicates',10);
result(j,:) = ClusteringMeasure(traingnd,label);

time_DR_test(j)=toc(tstart_test);
end %end times
ave_ACC=mean(result(:,1));    var_ACC=var(result(:,1));
ave_NMI=mean(result(:,2));    var_NMI=var(result(:,2));
ave_RI=mean(result(:,3));    var_RI=var(result(:,3));
ave_traintime_DR=mean(time_DR_train);  var_traintime_DR=var(time_DR_train);
ave_testtime_DR=mean(time_DR_test);   var_testtime_DR=var(time_DR_test);
ave_betas=mean(Betas,2);
end

