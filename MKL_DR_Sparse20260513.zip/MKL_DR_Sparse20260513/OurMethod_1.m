function [ave_accuracy,var_accuracy,ave_traintime_OURS,var_traintime_OURS,ave_betas]...
    =OurMethod_1(times,DataBase,width,tol2,max_IT2,max_IT,p1)
%  Our method--Computing A by Nystrom method--��С���ݣ����Թ��̣�
accuracy=zeros(times,1);
time_OURS_train=zeros(times,1);
m=length(width);
Betas=zeros(m,times);

for j = 1:times
tstart=tic;
     betas=ones(m,1)/m;
     eval(['load ' DataBase, '\','Train\',int2str(j),'.mat']); 
     nclass=length(unique(traingnd));  %�ܹ��������
     ReducedDim=nclass-1;
     n=size(trainfea,1);  %ѵ������������
     ntest=size(testfea,1);
%       options = [];
%       options.NeighborMode = 'KNN';
%       options.k = 5;
%       options.WeightMode = 'HeatKernel';
      options = [];
      options.NeighborMode = 'Supervised';
      options.gnd = traingnd;
      options.bLDA = 1;
%       options.WeightMode = 'HeatKernel';   
W = constructW(trainfea,options); %%% sparse sAffinity matrix
D=full(sum(W,2)); %column vector
% t_1=tic;
% W=kron(W,eye(ReducedDim,ReducedDim));
% D=D.^(-1);
% D=diag(D); % Diagonal matrix  D
% D_inverse=kron(D,eye(ReducedDim,ReducedDim));
% t_11=toc(t_1) 
IT=1;
while IT<max_IT
 %%%-----------Optimizacion of A (projection matrix)--------------
 t_2=tic;
    Label = unique(traingnd);
    rand('state',0);
    Y = rand(nclass,nclass);
    Z = zeros(n,nclass);
    for i=1:nclass
        idx = find(traingnd==Label(i));
        Z(idx,:) = repmat(Y(i,:),length(idx),1);
    end
    Z(:,1) = ones(n,1);
    [Y,~] = qr(Z,0);
    Y(:,1) = [];
t_22=toc(t_2)
t_3=tic;
% [A,err_A(j),IT_A(j),time_Decom_A(j)]=MYBlockREKcol_multiple_A(trainfea,Y,betas,tol1,max_IT1,width); 
% A=orth(A);
A=Nystrom_A(trainfea,Y,betas,width,p1);
t_33=toc(t_3)
%%%-----------Optimizing Betas (Kernel weights)--------------
t_4=tic;
 Y = rand(n,ReducedDim+1);
 Y(:,1) = ones(n,1);
 [Y,~] = qr(Y,0);
 Y(:,1) = [];
y=reshape(Y,n*ReducedDim,1);
% [y,~] = eigs(D_inverse*W,1) ; 
t_44=toc(t_4)
t_5=tic;
[betas,err_betas(j),IT_betas(j),time_Decom_betas(j)]=MYBlockREKcol_betas(trainfea,y,A,tol2,max_IT2,ReducedDim,width); 
t_55=toc(t_5)
t_6=tic;
betas = quadprog(eye(m,m),-betas,[],[],ones(1,m),1,zeros(m,1),ones(m,1));
t_66=toc(t_6)
IT=IT+1;
end %\end while
time_OURS_train(j)=toc(tstart);
Betas(:,j)=betas;
%%%----���棺m���˾���KERNELS�Լ�һ��mixed�˾���Kernel-------%%%
KERNELS=zeros(n,n,m);
for i=1:m
options=[];
options.KernelType = 'Gaussian';
options.t=width(i);
KERNELS(:,:,i)=constructKernel(trainfea,[],options);
end

Kernel=zeros(n,n);
  for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
 %%%--------- Data projected in the learned representation space-----------
trainData = zeros(n,size(A,2));    % size(A,2)=nclass-1
for i =1:n
    trainData(i,:) = Kernel(i,:)*A;
end
KERNELS_test=zeros(n,ntest,m);
for i=1:m
options=[];
options.KernelType = 'Gaussian';
options.t=width(i);
KERNELS_test(:,:,i)=constructKernel(trainfea,testfea,options);
end
    Kernel_test=zeros(n,ntest);
  for i=1:m
    Kernel_test=Kernel_test+betas(i)*KERNELS_test(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
testData = zeros(ntest,size(A,2));    % size(A,2)=nclass-1
for i =1:ntest
     testData_no= A'*Kernel_test(:,i);
     testData(i,:)=testData_no';
end
accuracy(j)=NN(trainData,testData,traingnd,testgnd);

end%\end times
ave_accuracy=mean(accuracy);    var_accuracy=var(accuracy);
ave_traintime_OURS=mean(time_OURS_train);  var_traintime_OURS=var(time_OURS_train);
ave_betas=mean(Betas,2);
end
