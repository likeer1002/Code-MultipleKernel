function y = KWDKtimesx(K,W,D,r,x)
%����y=K*(W-rD)*K
y=K*x;
y=(W-r*diag(D))*y;
y=K*y;

end

