close all
clear 
clc

times=5;
p=0.7;  %ѡ��70%��������Ϊѵ����

% DataBase='ORL_32x32';     %n=400(ntrain=280)
% DataBase='ORL_64x64';     %n=400(ntrain=280)
% DataBase='YaleB_64x64';   %n=2432(ntrain=1710)
% DataBase='AR_30x40';      %n=2600(ntrain=1900)
DataBase='sub_USPS';      %n=5000(ntrain=3500)
% DataBase='USPS';             %n=9298(ntrain=)
% DataBase='TDT2';             %n=9394(ntrain=6589)
% DataBase='PIE_32x32';     %n=11560(ntrain=8092)
% DataBase='Facescrub';        %n=22631(ntrain=15956) ��
% DataBase='CIFAR-100';        %n=60000(ntrain=42000)
% DataBase='MNIST';            %n=70000(ntrain=49005)
% DataBase='YouTubeFaceArrange_32x32';  %n=370319(ntrain=259369)


width=[0.1,0.22,0.46,1,2.15,4.46,10,21.54,46.42,100]';
Create_Train_Test(DataBase,p,times);

%%-------------MKL_DR method------------------%%
%     disp('Starting to Compute MKL_DR...')
%     step1=1; step2=0.5; %length of step
%     max_IT1=5;  max_IT2=5;
%     [ave_accuracy_1,var_accuracy_1,ave_time_SRTR_1,var_time_SRTR_1,ave_betas_1]=MKL_DR(times,DataBase,width,step1,max_IT1,step2,max_IT2);
%     disp(['MKL_DR����������ʱ��:',num2str(ave_time_DR_1)]);

%%-------------MKL_SRTR method------------------%%
%     disp('Starting to Compute MKL_SRTR...')
%     step1=1; step2=0.5; %length of step
%     max_IT1=5;  max_IT2=5;
%     [ave_accuracy_1,var_accuracy_1,ave_time_SRTR_1,var_time_SRTR_1,ave_betas_1]=MKL_SRTR_1(times,DataBase,width,step1,max_IT1,step2,max_IT2);
%     disp(['MKL_SRTR����������ʱ��:',num2str(ave_time_SRTR_1)]);

%%-------------Our method--Computing A by Kaczmarz method------------------%%
    % disp('Starting to Compute OurMethod...')
    % tol1=1e-2;  max_IT1=20; 
    % tol2=1e-2;  max_IT2=20;
    % max_IT=5;
    % [meanErr_A,meanErr_betas,ave_accuracy,var_accuracy,ave_time_OURS,var_time_OURS,ave_betas]=OurMethod(times,DataBase,width,tol1,max_IT1,tol2,max_IT2,max_IT);
    % disp(['Our Method������ʱ��:',num2str(ave_time_OURS)]);
% %%--------------Our method--Computing A by Nystrom method-----------------%%
%     disp('Starting to Compute OurMethod...')
%     tol2=1e-2;  max_IT2=20;
%     max_IT=5;
%     p1=0.1;   %Nystrom�еĲ�������
%     [ave_accuracy,var_accuracy,ave_time_OURS,var_time_OURS,ave_betas]=OurMethod_3(times,DataBase,width,tol2,max_IT2,max_IT,p1);
%     sum(ave_betas)
%     disp(['Our Method������ʱ��:',num2str(ave_time_OURS)]);

%%--------------Our Sparse method--Computing betas -----------------%%
    disp('Starting to Compute OurSparseMethod...')
    alg='OurSparseMethod';
    tol2=1e-2;  max_IT2=20;
    betas_tol=0.05;%1e-6
    max_IT=5;
    TrueOrFalse=1;
    
    step1=1e-1;% length of step used to update Lagrange multiplier
    p1=0.3;   %Nystrom�еĲ�������
%     gamma=1e-4;  % a parameter to trade off the clustering cost function and the regularization term.
    gamma=[2e-5,2e-4,2e-3,2e-2,2e-1,2,2e1,2e2,2e3,2e4,2e5]';
    lambda=0.1;   % Lagrange multiplier
%     [error_1,error_2,error_3,ave_Saccuracy,var_Saccuracy,ave_Stime_OURS,var_Stime_OURS,ave_Sbetas]=OurSparseMethod_1(times,DataBase,width,tol2,max_IT2,max_IT,p1,betas_tol,gamma,lambda,step1);
    error_1=zeros(length(gamma),1);
    error_2=zeros(length(gamma),1);
    error_3=zeros(length(gamma),1);
    ave_Saccuracy=zeros(length(gamma),1);
    ave_Straintime_OURS=zeros(length(gamma),1);
%     ave_Stesttime_OURS=zeros(length(gamma),1);
    ave_Sbetas=zeros(length(width),length(gamma));
    for i=1:length(gamma)
       [error_1(i),error_2(i),error_3(i),ave_Saccuracy(i),var_Saccuracy,ave_Straintime_OURS(i),var_Straintime_OURS,ave_Sbetas(:,i),ourgamma_lower(i),ourgamma_upper(i),first_sum(:,i),M]=OurSparseMethod_1_gamma(times,DataBase,width,tol2,max_IT2,max_IT,p1,betas_tol,gamma(i),lambda,step1,TrueOrFalse);
%            [error_1(i),error_2(i),error_3(i),ave_Saccuracy(i),var_Saccuracy,ave_Straintime_OURS(i),var_Straintime_OURS,ave_Sbetas(:,i)]=OurSparseMethod_1_gamma_1(times,DataBase,width,tol2,max_IT2,max_IT,p1,betas_tol,gamma(i),lambda,step1,TrueOrFalse);
    end



    