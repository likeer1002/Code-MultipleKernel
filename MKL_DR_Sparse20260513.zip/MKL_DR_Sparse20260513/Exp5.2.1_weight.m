%% 2022.10.5 The weights of base kernels learned by Algorithm 6 
close all
DataBase='MNIST database';

betas_tol=0.07;
m=14;
beta=betas(:,:,3);  %p=[0.4,0.6,0.8]';  %ѡ��p��������Ϊѵ����
for i=1:5
    each_beta=beta(:,i);
     each_beta(each_beta<betas_tol)=0;
     each_beta = each_beta/sum(each_beta);  
     if nnz(each_beta)/length(each_beta)>=0.7
         [~,idx]=sort(each_beta,'descend');
         each_beta(idx(0.5*m+1:end))=0;
         each_beta = each_beta/sum(each_beta);  % betas�ĳ�ֵѡȡ
     end
     beta(:,i)=each_beta;
end     

ave_beta=mean(beta,2);
std_beta=std(beta,0,2);
var_beta=std_beta.^2;
figure
    bar(ave_beta,'c');
    hold on;
    errorbar(ave_beta,var_beta,'r','LineStyle','none'); 
    title(DataBase);
    xlabel('Kernel index');
    ylabel('Weights');
    

