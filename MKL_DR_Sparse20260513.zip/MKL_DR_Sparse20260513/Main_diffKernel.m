close all
clear 
clc

times=5;
p=[0.2,0.4,0.6,0.8]';  %ѡ��p��������Ϊѵ����
% p=0.7;

DataBase='ORL_32x32';     %n=400(ntrain=280)
% DataBase='ORL_64x64';     %n=400(ntrain=280)
% DataBase='YaleB_64x64';   %n=2432(ntrain=1710)
% DataBase='AR_30x40';      %n=2600(ntrain=1900)
% DataBase='sub_USPS';      %n=5000(ntrain=3500)
% DataBase='USPS';             %n=9298(ntrain=)  accuracy����
% DataBase='TDT2';             %n=9394(ntrain=6589)
% DataBase='PIE_32x32';     %n=11560(ntrain=8092)
% DataBase='Facescrub';        %n=22631(ntrain=15956) ��
% DataBase='CIFAR-100';        %n=60000(ntrain=42000) ��
% DataBase='MNIST';            %n=70000(ntrain=49005)
% DataBase='YouTubeFaceArrange_32x32';  %n=370319(ntrain=259369)


global KernelTypes KernelPostProcessTypes Degrees;
KernelTypes = {'Linear', 'PolyPlus', 'PolyPlus', 'PolyPlus',... 
    'Polynomial','Polynomial','Polynomial', 'Gaussian', 'Gaussian',...
    'Gaussian', 'Gaussian', 'Gaussian', 'Gaussian','Gaussian'};
% KernelPostProcessTypes = {'Sample-Scale'};
KernelPostProcessTypes = {'MAX'};
Degrees = [1, 2, 4, 6, 2, 4, 6, 0.01, 0.05, 0.1, 1, 10, 50, 100]; % 14 base kernels

Create_Train_Test_diffp(DataBase,p,times);
% Create_Train_Test(DataBase,p,times);


%% -------------Our method--Computing A by Kaczmarz method------------------%%
    % disp('Starting to Compute OurMethod...')
    % tol1=1e-2;  max_IT1=20; 
    % tol2=1e-2;  max_IT2=20;
    % max_IT=5;
    % [meanErr_A,meanErr_betas,ave_accuracy,var_accuracy,ave_time_OURS,var_time_OURS,ave_betas]=OurMethod(times,DataBase,width,tol1,max_IT1,tol2,max_IT2,max_IT);
    % disp(['Our Method������ʱ��:',num2str(ave_time_OURS)]);
%%--------------Our method--Computing A by Nystrom method-----------------%%
%     memusage=zeros(length(p),1);
%     ave_accuracy=zeros(length(p),1);
%     ave_Traintime_OURS=zeros(length(p),1);
%     ave_Testtime_OURS=zeros(length(p),1);
%     ave_betas=zeros(length(Degrees),length(p));  
% for i=1:length(p)
%     disp('Starting to Compute OurMethod...')
%     alg='OurMethod';
%     tol2=1e-2;  max_IT2=20;
%     max_IT=5;
%     p1=0.3;   %Nystrom�еĲ�������
%     [memusage(i),ave_accuracy(i),var_accuracy,ave_Traintime_OURS(i),var_Traintime_OURS,ave_Testtime_OURS(i),var_Testtime_OURS,ave_betas(:,i)]...
%         =OurMethod_3_diffKernel(times,DataBase,tol2,max_IT2,max_IT,p1,p(i));
% end
% 
%     disp(['Our Method������ʱ��:',num2str(ave_Traintime_OURS(length(p)))]);
%     filename = strcat(alg,'+',DataBase,'+',num2str(p1),'+','multiplep','.mat'); % �洢���ļ���
%     save(strcat('Result','\','MKL_DR','\',filename),'Degrees','ave_accuracy','ave_Traintime_OURS','ave_Testtime_OURS','ave_betas','memusage','-v7.3');



%% -------------MKL_DR method------------------%%
    ave_DRaccuracy=zeros(length(p),1);
    ave_Traintime_DR=zeros(length(p),1);
    ave_Testtime_DR=zeros(length(p),1);
    ave_betas_DR=zeros(length(Degrees),length(p));  
    Installmex
    startup
for i=1:length(p)
    disp('Starting to Compute MKL_DR...')
    alg='MKL_DR';
    max_IT1=5;  
    [ave_DRaccuracy(i),var_accuracy_1,ave_Traintime_DR(i),var_Traintime_DR_1,ave_Testtime_DR(i),var_Testtime_DR_1,ave_betas_DR(:,i)]...
        =MKL_DR_diffKernel(times,DataBase,max_IT1,p(i));
end
    
    disp(['MKL_DR����������ʱ��:',num2str(ave_Traintime_DR(length(p)))]);
    filename = strcat(alg,'+',DataBase,'+','multiplep','.mat'); % �洢���ļ���
    save(strcat('Result','\','1Others','\',filename),'Degrees','ave_DRaccuracy','ave_Traintime_DR','ave_Testtime_DR','ave_betas_DR','-v7.3');

    filename = strcat(alg,'+',DataBase,'+','multiplep_1','.mat'); % �洢���ļ���
    save(strcat('Result','\',filename),'Degrees','ave_DRaccuracy','ave_Traintime_DR','ave_Testtime_DR','ave_betas_DR','-v7.3');


%% -------------MKL_SRTR method------------------%%
% %     SRTR_memusage=zeros(length(p),1);
%     ave_SRTRaccuracy=zeros(length(p),1);
%     ave_Traintime_SRTR=zeros(length(p),1);
%     ave_Testtime_SRTR=zeros(length(p),1);
%     ave_betas_SRTR=zeros(length(Degrees),length(p));  
% for i=1:length(p)
%     disp('Starting to Compute MKL_SRTR...')
%     alg='MKL_SRTR';
%     step1=1; step2=0.5; %length of step
%     max_IT1=5;  max_IT2=5;
%     [ave_SRTRaccuracy(i),var_accuracy_1,ave_Traintime_SRTR(i),var_Traintime_SRTR_1,ave_Testtime_SRTR(i),var_Testtime_SRTR_1,ave_betas_SRTR(:,i)]...
%         =MKL_SRTR_1_diffKernel(times,DataBase,step1,max_IT1,step2,max_IT2,p(i));
% end
%     
%     disp(['MKL_SRTR����������ʱ��:',num2str(ave_Traintime_SRTR(length(p)))]);
%     filename = strcat(alg,'+',DataBase,'+','multiplep','.mat'); % �洢���ļ���
%     save(strcat('Result','\',filename),'Degrees','ave_SRTRaccuracy','ave_Traintime_SRTR','ave_Testtime_SRTR','ave_betas_SRTR','-v7.3');

    