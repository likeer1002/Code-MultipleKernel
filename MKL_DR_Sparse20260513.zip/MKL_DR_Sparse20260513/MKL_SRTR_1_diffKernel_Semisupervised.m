function [ave_ACC,var_ACC,ave_traintime_SRTR,var_traintime_SRTR,ave_testtime_SRTR,var_testtime_SRTR,ave_betas]...
    =MKL_SRTR_1_diffKernel_Semisupervised(times,DataBase,step1,max_IT1,step2,max_IT2,p1,p)
%  ��MKL_SRTR����Multiple kernel dimensionality reduction via spectral regression and trace ratio maximization
global KernelTypes KernelPostProcessTypes Degrees;
time_SRTR_train=zeros(times,1);
time_SRTR_test=zeros(times,1);
m=length(Degrees);
Betas=zeros(m,times);
for j = 1:times
tstart=tic;
     file = strcat('semi','_',DataBase,'\','Train\',num2str(p),'\',int2str(j),'.mat');
%      file = strcat(DataBase,'\','Train\',int2str(j),'.mat');

     load(file, 'trainfea','traingnd');
     [feaLabel,gndLabel,feaTrain] = Partial_Label(trainfea,traingnd,0.1); % %����ǩ����ռѵ����������0.1
     nclass=length(unique(gndLabel));  %�ܹ��������
     ReducedDim=nclass-1;
     feaAll = [feaLabel;feaTrain];
     n=size(feaAll,1);  %ѵ������������

    options=[];
    options.NeighborMode = 'KNN';
    options.k = 15;
    options.WeightMode = 'Binary';
    S = constructW(feaAll,options);  %����S in (45)
    options=[];
    options.NeighborMode = 'Supervised';
    options.gnd = gndLabel;  %����ǩ������gnd
    options.bLDA = 1;     
    W = constructW(feaLabel,options); 
    W=blkdiag(W,zeros(size(feaTrain,1)));
W=W+0.1*S;   %����W in (43)   ,sparse Affinity matrix
D=full(sum(W,2));   %Column vector
% D=sparse(diag(D));   % Diagonal matrix  D
KERNELS=zeros(n,n,m);
for i=1:m
    kernel_option = [];
     switch lower(KernelTypes{i})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel,KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(i);
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(i);
                kernel=constructKernel(trainfea,[],kernel_option);
                kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(i);
                  kernel=constructKernel(trainfea,[],kernel_option);
                  kernel = KernelNormalize(kernel, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
     end
KERNELS(:,:,i)=kernel;
end

r=1;
f_r=1;
it=1;
while f_r~=0 && it<max_IT1
    [A,betas]=MKL_SRTR_ADM_1(KERNELS,D,W,n,nclass,ReducedDim,r,step2,max_IT2,m); %Alternating projections
    Kernel=zeros(n,n);
  for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
  
     [~,deltas_D]=eig(Kernel*(W-r*diag(D))*Kernel);
%     sigma=eigs(@(x)KWDKtimesx(Kernel,W,D,r,x),n,ReducedDim,'lm');%���
%     f_r=sum(diag(deltas_D));
    [deltas_D,~]=sort(diag(deltas_D),'descend');
    f_r=sum(deltas_D(1:ReducedDim));
    
    C=D.^(1/2).*Kernel*A;
    d_f_r=-norm(C,'fro')^2;
    r=r-step1*f_r/d_f_r;
%     d_betas=zeros(m,1);
%   for i=1:m
%     d_betas(i)=trace(2*A'*KERNELS(:,:,i)*(W-r*diag(D))*Kernel*A);  
%   end
%     betas=betas+step2*d_betas/norm(d_betas);  
% %     e=ones(m,1);
% %     cvx_begin
% %        variable p(m)
% %        minimize(norm(p-betas,2)^2)
% %        subject to
% %           p'*e==1;
% %           p>=0;  
% %     cvx_end
% %     betas=p;
% 
%   betas = quadprog(eye(m,m),-real(betas),[],[],ones(1,m),1,zeros(m,1),ones(m,1));
%   betas(betas<1e-6)=0;
%   betas = betas/sum(betas);
  it=it+1;
end   %end while
time_SRTR_train(j)=toc(tstart);
Betas(:,j)=betas;
 %%%--------- Data projected in the learned representation space-----------
tstart_test=tic;

%%%-----------------------------------------------%%%
load(file, 'testfea','testgnd');
ntest=size(testfea,1);
m11=floor(p1*ntest);  %�˾���n*ntest�����в����У�ÿ�βɵ�����  
p11=floor(1/p1);  %�˾���n*ntest�����в����У��ɵĴ���  
testData = zeros(ntest,size(A,2));    % size(A,2)=nclass-1
for i =1:p11
    Kernel_sub=zeros(n,m11); 
    Rtestfea=testfea((i-1)*m11+1:i*m11,:);
   for jj=1:m
     kernel_option = [];
     switch lower(KernelTypes{jj})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(jj);
                        Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                        Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
    end 
        Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
  end
    testData_no = A'*Kernel_sub;
    testData((i-1)*m11+1:i*m11,:)=testData_no';
end
clear Rtestfea Kernel_sub_1 Kernel_sub
if ntest-m11*p11>0
Kernel_sub=zeros(n,ntest-m11*p11);
Rtestfea=testfea(m11*p11+1:ntest,:);
  for jj=1:m
     kernel_option = [];
     switch lower(KernelTypes{jj})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(jj);
                    Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                    Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(jj);
                        Kernel_sub_1 = constructKernel(trainfea,Rtestfea, kernel_option);
                        Kernel_sub_1 = KernelNormalize(Kernel_sub_1, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
    end 
        Kernel_sub=Kernel_sub+betas(jj)*Kernel_sub_1;
  end
testData_no=A'*Kernel_sub;
testData(m11*p11+1:ntest,:)=testData_no';
clear Rtestfea Kernel_sub_1 Kernel_sub testfea
end

label=litekmeans(testData,nclass,'MaxIter',100,'Replicates',10);
result(j,:) = ClusteringMeasure(testgnd,label);
time_SRTR_test(j)=toc(tstart_test);
end %end times

ave_ACC=mean(result(:,1));    var_ACC=var(result(:,1));
% ave_NMI=mean(result(:,2));    var_NMI=var(result(:,2));
% ave_RI=mean(result(:,3));    var_RI=var(result(:,3));
ave_traintime_SRTR=mean(time_SRTR_train);  var_traintime_SRTR=var(time_SRTR_train);
ave_testtime_SRTR=mean(time_SRTR_test);   var_testtime_SRTR=var(time_SRTR_test);
ave_betas=mean(Betas,2);
end

