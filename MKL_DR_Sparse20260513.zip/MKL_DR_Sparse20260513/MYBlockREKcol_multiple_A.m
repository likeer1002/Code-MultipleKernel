function [X1,error,IT,time]=MYBlockREKcol_multiple_A(trainfea,Y,betas,tol,iter,width) %�����ģ���� 
%block randomized extended kaczmarz algorithm(ֻ����)
%���Ҷ��һ������⣨ours��
m=length(width);
n=size(trainfea,1); 
d=size(Y,2); 
X0=zeros(n,d);
X1=zeros(n,d);
Z0=Y;
Bnorm=norm(Y,'fro');
tstart=tic;
IT=0;
 
h=100; %�ɸı�
hi=h/2;

err=1;
q=[];

while err>tol && IT<iter
     w=randperm(n);  %����Z
     w1=w(1:hi);
     Rtrainfea=trainfea(w1,:);        %���ѡȡ��R������
KERNELS_sub=zeros(n,hi,m);
for i=1:m
    options=[];
    options.KernelType = 'Gaussian';
    options.t=width(i);
   KERNELS_sub(:,:,i) = constructKernel(trainfea,Rtrainfea,options);
end
K_sub=zeros(n,hi);
for j=1:hi
    K_i=reshape(KERNELS_sub(:,j,:),n,m);
    K_sub(:,j)=K_i*betas;
end
     [U,S,V]=svd(K_sub,'econ');  
     W=V*(diag(diag(S).^(-1))*(U'*Z0));
     X1(w1',:)=X0(w1',:)+W;
     Z1=Z0-K_sub*W;
    
%     err0=B-A*X1;
%     err1=norm(err0,'fro')^2/norm(B,'fro')^2;
%     err=norm(A'*err0,'fro')^2/norm(A'*B,'fro')^2; 
   
    err=norm(W,'fro')/Bnorm;

% err1=norm(X1-X_LS,'fro')/norm(X_LS,'fro');

    X0=X1;
    Z0=Z1;
    IT=IT+1;
    q(IT,1)=err;

end
time=toc(tstart);
error=q(end,1);
end
