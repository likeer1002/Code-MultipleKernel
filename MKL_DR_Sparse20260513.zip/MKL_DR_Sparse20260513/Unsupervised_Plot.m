% %% ACC
% figure;
% %             plot(ave_DRacc,'r-o')
% %             hold on
% %             plot(ave_SRacc,'c-s')
% %             hold on
% %             plot(ave_TRacc,'m-h')
% %             hold on
%             plot(ave_SRTRacc,'b-*')
%             hold on
%             plot(ave_ACC,'g-+')
%             hold on
%             plot(ave_sACC,'k-v')
%             hold off
%             % ORL_{32\times 32},Sub_{USPS},PIE_{32\times 32}
% title('Comparison of ACC on six algorithms on the $PIE_{32\times 32}$ database','fontname','Times New Roman','FontSize',20,'Interpreter','latex');
% % axis([1 10 1e-6 2]); % �����᳤������,ǰ2��ֵ��ӦX ��,��2��ֵ��Ӧ Y��
% xlabel('Ratio','FontName','Times New Roman','FontSize',16);%,'FontAngle','italic'); % x���Ǵ�С,����
% ylabel('ACC','FontName','Times New Roman','FontSize',16); % y���Ǵ�С,����
% % T = legend('DR algorithm','SR algorithm','TR algorithm','SRTR algorithm','Our method 1 algorithm','Sparse algorithm');% 'UODV','LUDT','LUDP','LDE','LULDE'
% T = legend('SRTR algorithm','Our method 1 algorithm','Sparse algorithm');% 'UODV','LUDT','LUDP','LDE','LULDE'
% 
% 
% %% NMI
% figure;
% %             plot(ave_DRnmi,'r-o')
% %             hold on
% %             plot(ave_SRnmi,'c-s')
% %             hold on
% %             plot(ave_TRnmi,'m-h')
% %             hold on
%             plot(ave_SRTRnmi,'b-*')
%             hold on
%             plot(ave_NMI,'g-+')
%             hold on
%             plot(ave_sNMI,'k-v')
%             hold off
%            % ORL_{32\times 32},Sub_{USPS},PIE_{32\times 32}
% title('Comparison of NMI on six algorithms on the $PIE_{32\times 32}$ database','fontname','Times New Roman','FontSize',20,'Interpreter','latex');
% % axis([1 10 1e-6 2]); % �����᳤������,ǰ2��ֵ��ӦX ��,��2��ֵ��Ӧ Y��
% xlabel('Ratio','FontName','Times New Roman','FontSize',16);%,'FontAngle','italic'); % x���Ǵ�С,����
% ylabel('NMI','FontName','Times New Roman','FontSize',16); % y���Ǵ�С,����
% % T = legend('DR algorithm','SR algorithm','TR algorithm','SRTR algorithm','Our method 1 algorithm','Sparse algorithm');% 'UODV','LUDT','LUDP','LDE','LULDE'
% T = legend('SRTR algorithm','Our method 1 algorithm','Sparse algorithm');% 'UODV','LUDT','LUDP','LDE','LULDE'

%%  RI
figure; 
            plot(ave_DRri,'r-o')
            hold on
            plot(ave_SRri,'c-s')
            hold on
            plot(ave_TRri,'m-h')
            hold on
            plot(ave_SRTRri,'b-*')
            hold on
            plot(ave_RI,'g-+')
            hold on
            plot(ave_sRI,'k-v')
            hold off
          % ORL_{32\times 32},Sub_{USPS},PIE_{32\times 32}
title('Comparison of RI on six algorithms on the $ PIE_{32\times 32}$ database','fontname','Times New Roman','FontSize',20,'Interpreter','latex');
% axis([1 10 1e-6 2]); % �����᳤������,ǰ2��ֵ��ӦX ��,��2��ֵ��Ӧ Y��
xlabel('Ratio','FontName','Times New Roman','FontSize',16);%,'FontAngle','italic'); % x���Ǵ�С,����
ylabel('RI','FontName','Times New Roman','FontSize',16); % y���Ǵ�С,����
T = legend('DR algorithm','SR algorithm','TR algorithm','SRTR algorithm','Our method 1 algorithm','Sparse algorithm');% 'UODV','LUDT','LUDP','LDE','LULDE'
% T = legend('SRTR algorithm','Our method 1 algorithm','Sparse algorithm');% 'UODV','LUDT','LUDP','LDE','LULDE'



