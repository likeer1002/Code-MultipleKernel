close all
clear 
clc

times=5;
p=0.7;  %ѡ��70%��������Ϊѵ����

% DataBase='ORL_32x32';     %n=400(ntrain=280)
DataBase='YaleB_64x64';   %n=2432(ntrain=1710)
% DataBase='AR_30x40';      %n=2600(ntrain=1900)
% DataBase='sub_USPS';      %n=5000(ntrain=3500)
% DataBase='USPS';             %n=9298(ntrain=)  ��
% DataBase='TDT2';             %n=9394(ntrain=6589)
% DataBase='PIE_32x32';     %n=11560(ntrain=8092)
% DataBase='Facescrub';        %n=22631(ntrain=15956) ��
% DataBase='CIFAR-100';        %n=60000(ntrain=42000) ��
% DataBase='MNIST';            %n=70000(ntrain=49005)
% DataBase='YouTubeFaceArrange_32x32';  %n=370319(ntrain=259369)


width=[0.1,0.22,0.46,1,2.15,4.46,10,21.54,46.42,100]';
Create_Train_Test(DataBase,p,times);


%%-------------MKL_SRTR method------------------%%
    disp('Starting to Compute MKL_SRTR...')
    step1=1; step2=0.5; %length of step
    max_IT1=5;  max_IT2=5;
    [ave_accuracy_1,var_accuracy_1,ave_time_SRTR_1,var_time_SRTR_1,ave_betas_1]...
        =MKL_SRTR_1(times,DataBase,width,step1,max_IT1,step2,max_IT2);
    disp(['MKL_SRTR����������ʱ��:',num2str(ave_time_SRTR_1)]);

%%--------------Our method--Computing A by Nystrom method-----------------%%
%     disp('Starting to Compute OurMethod...')
%     tol2=1e-2;  max_IT2=20;
%     max_IT=5;
%     p1=0.3;   %Nystrom�еĲ�������
%     [ave_accuracy,var_accuracy,ave_Traintime_OURS,var_Traintime_OURS,ave_Testtime_OURS,var_Testtime_OURS,ave_betas]=OurMethod_3(times,DataBase,width,tol2,max_IT2,max_IT,p1);
%    
%     disp(['Our Method������ʱ��:',num2str(ave_Traintime_OURS)]);

