function [betas,time]=QRComputing_betas(trainfea,y,A,ReducedDim,width)  %�����ģ���� 
%��ʽ�γ�ϵ��������QR�ֽ�
%���Ҷ�
m=length(width);
n=size(trainfea,1); 
% betas=zeros(m,1);
tstart=tic;
K_sub=zeros(n*ReducedDim,m);
for i=1:m
           options=[];
           options.KernelType = 'Gaussian';
           options.t=width(i);
           K_i = constructKernel(trainfea,[],options);  
      K_sub(:,i)=reshape(A'*K_i,n*ReducedDim,1);
end 
clear  K_i 


[Q,R]=qr(K_sub,0);
clear K_sub 
betas=R\(Q'*y);
% betas=(R'*R)\(R'*(Q'*y));

time=toc(tstart);

end
