close all

Database='Extended YaleB database';

gammas=[2.^(-12:12)];
gammas_log=log2(gammas);
std_Saccuracy=var_Saccuracy.^(1/2);
figure
plot(gammas_log,ave_Saccuracy,'b-*','linewid',3);
hold on
fill([gammas_log,fliplr(gammas_log)],[ave_Saccuracy-std_Saccuracy,fliplr(ave_Saccuracy+std_Saccuracy)],[0.3010 0.7450 0.9330],'edgecolor','none');
alpha(0.2);  %alpha(0.2)������20%�ı���͸���ȣ�
hold off

title(Database);
xlabel('$\bf{\log_2{\gamma}}$','FontName','Times New Roman','FontSize',16,'Interpreter','latex');%,'FontAngle','italic'); % x���Ǵ�С,����
ylabel('Classification accuracy'); % y���Ǵ�С,����
