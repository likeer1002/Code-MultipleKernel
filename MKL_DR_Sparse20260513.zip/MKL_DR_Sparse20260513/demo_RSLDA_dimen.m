function [ave_accuracy,var_accuracy,ave_time,var_traintime,var_testtime]...
    =demo_RSLDA_dimen(nRepeat,dataset,p,ReducedDim)
% Create_Train_Test_diffp(DataBase,0.4,times,1); 
% datasets={'ORL'};
 
addpath('./RSLDA/');
addpath('./lib');

% accuracy=zeros(times,1);
time_train=zeros(nRepeat,1);
time_test=zeros(nRepeat,1);
for j = 1:nRepeat
tstart=tic;
     file = strcat(dataset,'\','Train\',num2str(p),'\',int2str(j),'.mat');
     load(file, 'trainfea','traingnd');
     % nclass=length(unique(traingnd));  %�ܹ��������
     % ReducedDim=nclass-1;
%      n=size(trainfea,1);  %������

% -------------   set parameters ---------------- %
lambda1 = 0.00001;
lambda2 = 0.0001;
dim = ReducedDim;
mu  = 0.1;
rho = 1.01;
max_iter = 100;

[P,Q,E,obj] = RSLDA(trainfea',traingnd,lambda1,lambda2,dim,mu,rho,max_iter);
time_train(j)=toc(tstart);
%����
tstart_test=tic;
trainData = Q'*trainfea';
load(file, 'testfea','testgnd');
testData  = Q'*testfea';
accuracy(j)=NN(trainData',testData',traingnd,testgnd);
time_test(j)=toc(tstart_test);
end

ave_accuracy=mean(accuracy);    var_accuracy=var(accuracy);
ave_traintime=mean(time_train);  var_traintime=var(time_train);
ave_testtime=mean(time_test);   var_testtime=var(time_test);
ave_time=ave_traintime+ave_testtime;
% result_dir = fullfile(pwd,['result_RSLDA_' num2str(nRepeat)],[dataset,'_result']);
% if ~exist(result_dir,'dir')
%     mkdir(result_dir);
% end
% 
% result_file = fullfile(result_dir,[dataset,'_RSLDA','.mat']);
% save(result_file,'ReducedDims','ave_accuracy','var_accuracy','ave_time','var_traintime','var_testtime','accuracy','time_train','time_test');
% disp('RSLDA done');

end