close all
clear 
clc   
%% Unsupervised Learning to compute STAC
%��sparse������Ϊ����һ��Ԥ������������У��ﵽ���ٲ���ʱ���Ч��
times=5;
% p=[0.2,0.4,0.6,0.8]';  %ѡ��p��������Ϊѵ����
p=[0.4,0.6,0.8]';  %ѡ��p��������Ϊѵ����
% p=0.8;

DataBase='ORL_32x32';     %n=400(ntrain=280)
% DataBase='ORL_64x64';     %n=400(ntrain=280)
% DataBase='COIL20';     %n=1440(ntrain=1008)
% DataBase='YaleB_64x64';   %n=2432(ntrain=1710)
% DataBase='AR_30x40';      %n=2600(ntrain=1900)
% DataBase='sub_USPS';      %n=5000(ntrain=3500)
% DataBase='USPS';             %n=9298(ntrain=)
% DataBase='TDT2';             %n=9394(ntrain=6589)
% DataBase='PIE_32x32';     %n=11560(ntrain=8092)
% DataBase='Facescrub';        %n=22631(ntrain=15956) ��
% DataBase='CIFAR-100';        %n=60000(ntrain=42000)��
% DataBase='MNIST';            %n=70000(ntrain=49005)
% DataBase='YouTubeFace_128x128_2000';  %n=(ntrain=)
% DataBase='FounderType-17_64x64';

global KernelTypes KernelPostProcessTypes Degrees;
KernelTypes = {'Linear', 'PolyPlus', 'PolyPlus', 'PolyPlus',... 
    'Polynomial','Polynomial','Polynomial', 'Gaussian', 'Gaussian',...
    'Gaussian', 'Gaussian', 'Gaussian', 'Gaussian','Gaussian'};
KernelPostProcessTypes = 'MAX'; % KernelPostProcessTypes = {'Sample-Scale'};
Degrees = [1, 2, 4, 6, 2, 4, 6, 0.01, 0.05, 0.1, 1, 10, 50, 100]; % 14 base kernels
m=length(Degrees);

% Create_Train_Test_diffp(DataBase,p,times,1);

%% �����Ժ˷���
    tol2=1e-2;  max_IT2=20;
    betas_tol=0.07;%1e-6
    max_IT=5;
    Pre_max_IT=2;  %Sparse������������2
    
    p1=0.3;   %Nystrom�еĲ�������0.1��0.3
    Pre_p1=0.1;   %Sparse��Nystrom�еĲ�������0.05��0.1

    step1=1e-1;% length of step used to update Lagrange multiplier
%     gamma=[2e-2,2e-1,2,2e1,2e2,2e3]';  % a parameter to trade off the clustering cost function and the regularization term.
    gamma=0.1;  %  gamma=0.2;
    lambda=0.1;   % Lagrange multiplier

%%  --------------Our Sparse method--Computing betas -----------------%%

    ave_Straintime_OURS=zeros(length(p),1);
    var_Straintime_OURS=zeros(length(p),1);
    betas=zeros(m,times,length(p));
    ave_betas=zeros(m,length(p));
for i=1:length(p)
    disp('Starting to Compute OurSparseMethod...')
    alg='Precond_OurSparse';

%     [error_1,error_2,error_3,ave_Saccuracy,var_Saccuracy,ave_Stime_OURS,var_Stime_OURS,ave_Sbetas]=OurSparseMethod_1(times,DataBase,width,tol2,max_IT2,max_IT,p1,betas_tol,gamma,lambda,step1);
%     error_1=zeros(length(gamma),1);
%     error_2=zeros(length(gamma),1);
%     error_3=zeros(length(gamma),1);
%     ave_Saccuracy=zeros(length(gamma),1);
%     ave_Straintime_OURS=zeros(length(gamma),1);
%     ave_Stesttime_OURS=zeros(length(gamma),1);
%     ave_Sbetas=zeros(length(Degrees),length(gamma));  
[BIG_betas,ave_Straintime_OURS(i),var_Straintime_OURS(i),betas(:,:,i)]=...
    OurSparse_diffK_Precond_Unsupervised(times,DataBase,tol2,max_IT2,Pre_max_IT,Pre_p1,betas_tol,gamma,lambda,step1,p(i));

       
end

    filename = strcat(alg,'+',DataBase,'+',num2str(p1),'+',num2str(betas_tol),'+','multiplep','+','Precondition','.mat'); % �洢���ļ���
    save(strcat('Result','\','Unsupervised','\','3MKL_DR_Sparse','\',filename),'Degrees','ave_Straintime_OURS','var_Straintime_OURS','betas','-v7.3');
    disp(['Our Sparse Method������ʱ��:',num2str(ave_Straintime_OURS(length(p)))]);
%     % plot weights ,i.e., betas
%     [~,accidx]=max(ave_Saccuracy);
%     figure
%     bar(ave_Sbetas(:,accidx))
%     file = strcat(DataBase,'\','Train\',int2str(1),'.mat');
%     load(file,'traingnd');
%     title(strcat(DataBase,'(with n=',num2str(length(traingnd)),')'));
%     xlabel('Kernel index');
%     ylabel('Weights');

%% --------------Ԥ������Our method 1------------------%%

    ave_PreTraintime_OURS=zeros(length(p),1);
    var_PreTraintime_OURS=zeros(length(p),1);

for i=1:length(p)
     
     disp('Starting to Compute Precond_OurMethod...')
     alg='Precond_OurMethod';
     
[result(:,:,i),ave_sACC(i),var_sACC(i),ave_sNMI(i),var_sNMI(i),ave_sRI(i),var_sRI(i),ave_PreTraintime_OURS(i),var_PreTraintime_OURS(i),ave_PreTesttime_OURS(i),var_PreTesttime_OURS(i)]...
    =OurMethod_diffK_Precond_Unsupervised(times,DataBase,tol2,max_IT2,max_IT,p1,p(i),betas_tol,betas(:,:,i));
     

end

    disp(['Our Method������ʱ��:',num2str(ave_PreTraintime_OURS(length(p)))]);
    filename = strcat(alg,'+',DataBase,'+',num2str(p1),'+','multiplep','+','Precondition','.mat'); % �洢���ļ���
    save(strcat('Result','\','Unsupervised','\','3MKL_DR_Sparse','\',filename),'Degrees','ave_PreTraintime_OURS','var_PreTraintime_OURS','ave_PreTesttime_OURS','var_PreTesttime_OURS','ave_sACC','var_sACC','ave_sNMI','var_sNMI','ave_sRI','var_sRI','result','-v7.3');

  
%% -------------Our method 1--Computing A by Kaczmarz method------------------%%
    % disp('Starting to Compute OurMethod...')
    % tol1=1e-2;  max_IT1=20; 
    % tol2=1e-2;  max_IT2=20;
    % max_IT=5;
    % [meanErr_A,meanErr_betas,ave_accuracy,var_accuracy,ave_time_OURS,var_time_OURS,ave_betas]=OurMethod(times,DataBase,width,tol1,max_IT1,tol2,max_IT2,max_IT);
    % disp(['Our Method������ʱ��:',num2str(ave_time_OURS)]);
%%--------------Our method 1--Computing A by Nystrom method-----------------%%
    ave_ACC=zeros(length(p),1);
    var_ACC=zeros(length(p),1);
    ave_Traintime_OURS=zeros(length(p),1);
    var_Traintime_OURS=zeros(length(p),1);
    ave_Testtime_OURS=zeros(length(p),1);
    var_Testtime_OURS=zeros(length(p),1);
    ave_betas=zeros(length(Degrees),length(p));  
for i=1:length(p)
    disp('Starting to Compute OurMethod...')
    alg='OurMethod';

    [result(:,:,i),ave_ACC(i),var_ACC(i),ave_NMI(i),var_NMI(i),ave_RI(i),var_RI(i),ave_Traintime_OURS(i),var_Traintime_OURS(i),ave_Testtime_OURS(i),var_Testtime_OURS(i),ave_betas(:,i)]...
        =OurMethod_diffK_Unsupervised(times,DataBase,tol2,max_IT2,max_IT,p1,p(i));
end

    disp(['Our Method������ʱ��:',num2str(ave_Traintime_OURS(length(p)))]);
    filename = strcat(alg,'+',DataBase,'+',num2str(p1),'+','multiplep','.mat'); % �洢���ļ���
    save(strcat('Result','\','Unsupervised','\','2MKL_DR','\',filename),'Degrees','ave_ACC','var_ACC','ave_NMI','var_NMI','ave_RI','var_RI','ave_Traintime_OURS','var_Traintime_OURS','ave_Testtime_OURS','var_Testtime_OURS','ave_betas','result','-v7.3');

  
    
%     
% %% -------------MKL_SRTR method------------------%%
%     ave_traintime_SRTR=zeros(length(p),1);
%     var_traintime_SRTR=zeros(length(p),1);
%     ave_testtime_SRTR=zeros(length(p),1);
%     var_testtime_SRTR=zeros(length(p),1);
% %     ave_betas_SRTR=zeros(length(Degrees),length(p));  
% for i=1:length(p)
%     disp('Starting to Compute MKL_SRTR...')
%     alg='MKL_SRTR';
%     step1=1; step2=0.5; %length of step
%     max_IT1=5;  max_IT2=5;
%     [ave_SRTRacc(i),var_SRTRacc(i),ave_SRTRnmi(i),var_SRTRnmi(i),ave_SRTRri(i),var_SRTRri(i),ave_traintime_SRTR(i),var_traintime_SRTR(i),ave_testtime_SRTR(i),var_testtime_SRTR(i),ave_betas(:,i)]...
%     =MKL_SRTR_1_diffKernel_Unsupervised(times,DataBase,step1,max_IT1,step2,max_IT2,p1,p(i)); 
% end
%     
%     disp(['MKL_SRTR����������ʱ��:',num2str(ave_traintime_SRTR(length(p)))]);
%     filename = strcat(alg,'+',DataBase,'+','multiplep','.mat'); % �洢���ļ���
%     save(strcat('Result','\','Unsupervised','\','1Others','\',filename),'Degrees','ave_SRTRacc','var_SRTRacc','ave_SRTRnmi','var_SRTRnmi','ave_SRTRri','var_SRTRri','ave_traintime_SRTR','var_traintime_SRTR','ave_testtime_SRTR','var_testtime_SRTR','ave_betas','-v7.3');
% 
%     
% %% -------------MKL_TR method------------------%%
%     ave_TRacc=zeros(length(p),1);
%     var_TRacc=zeros(length(p),1);
%     ave_Traintime_TR=zeros(length(p),1);
%     var_Traintime_TR=zeros(length(p),1);
%     ave_Testtime_TR=zeros(length(p),1);
%     var_Testtime_TR=zeros(length(p),1);
%     ave_betas_TR=zeros(length(Degrees),length(p));  
% for i=1:length(p)
%     disp('Starting to Compute MKL_TR...')
%     alg='MKL_TR';
%     step1=1; step2=0.5; %length of step
%     max_IT1=5;  max_IT2=5;
%     lambda_TR=1e-4;
%     [ave_TRacc(i),var_TRacc(i),ave_TRnmi(i),var_TRnmi(i),ave_TRri(i),var_TRri(i),ave_Traintime_TR(i),var_Traintime_TR(i),ave_Testtime_TR(i),var_Testtime_TR(i),ave_betas_TR(:,i)]...
%         =MKL_TR_diffKernel_1_Unsupervised(times,DataBase,lambda_TR,step1,max_IT1,step2,max_IT2,p1,p(i));
% end
%     
%     disp(['MKL_TR����������ʱ��:',num2str(ave_Traintime_TR(length(p)))]);
%     filename = strcat(alg,'+',DataBase,'+','multiplep','.mat'); % �洢���ļ���
%     save(strcat('Result','\','Unsupervised','\','1Others','\',filename),'Degrees','ave_TRacc','var_TRacc','ave_TRnmi','var_TRnmi','ave_TRri','var_TRri','ave_Traintime_TR','var_Traintime_TR','ave_Testtime_TR','var_Testtime_TR','ave_betas_TR','-v7.3');
% 
%     
% %% -------------MKL_SR method------------------%%
%     ave_SRacc=zeros(length(p),1);
%     var_SRacc=zeros(length(p),1);
%     ave_Traintime_SR=zeros(length(p),1);
%     var_Traintime_SR=zeros(length(p),1);
%     ave_Testtime_SR=zeros(length(p),1);
%     var_Testtime_SR=zeros(length(p),1);
%     ave_betas_SR=zeros(length(Degrees),length(p));  
%     Installmex
%     startup
% for i=1:length(p)
%     disp('Starting to Compute MKL_SR...')
%     alg='MKL_SR';
%     max_IT1=5;  
%     [ave_SRacc(i),var_SRacc(i),ave_SRnmi(i),var_SRnmi(i),ave_SRri(i),var_SRri(i),ave_Traintime_SR(i),var_Traintime_SR(i),ave_Testtime_SR(i),var_Testtime_SR(i),ave_betas_SR(:,i)]...
%         =MKL_SR_diffKernel_Unsupervised(times,DataBase,max_IT1,p1,p(i));
% end
%     
%     disp(['MKL_SR����������ʱ��:',num2str(ave_Traintime_SR(length(p)))]);
%     filename = strcat(alg,'+',DataBase,'+','multiplep','.mat'); % �洢���ļ���
%     save(strcat('Result','\','Unsupervised','\','1Others','\',filename),'Degrees','ave_SRacc','var_SRacc','ave_SRnmi','var_SRnmi','ave_SRri','var_SRri','ave_Traintime_SR','var_Traintime_SR','ave_Testtime_SR','var_Testtime_SR','ave_betas_SR','-v7.3');
%  
%  
% %% -------------MKL_DR method------------------%%
%     ave_DRacc=zeros(length(p),1);
%     var_DRacc=zeros(length(p),1);
%     ave_Traintime_DR=zeros(length(p),1);
%     var_Traintime_DR=zeros(length(p),1);
%     ave_Testtime_DR=zeros(length(p),1);
%     var_Testtime_DR=zeros(length(p),1);
%     ave_betas_DR=zeros(length(Degrees),length(p));  
%     Installmex
%     startup
% for i=1:length(p)
%     disp('Starting to Compute MKL_DR...')
%     alg='MKL_DR';
%     max_IT1=5;  
%     [ave_DRacc(i),var_DRacc(i),ave_DRnmi(i),var_DRnmi(i),ave_DRri(i),var_DRri(i),ave_Traintime_DR(i),var_Traintime_DR(i),ave_Testtime_DR(i),var_Testtime_DR(i),ave_betas_DR(:,i)]...
%         =MKL_DR_diffKernel_1_Unsupervised(times,DataBase,max_IT1,p1,p(i));
% end
%     
%     disp(['MKL_DR����������ʱ��:',num2str(ave_Traintime_DR(length(p)))]);
%     filename = strcat(alg,'+',DataBase,'+','multiplep','.mat'); % �洢���ļ���
%     save(strcat('Result','\','Unsupervised','\','1Others','\',filename),'Degrees','ave_DRacc','var_DRacc','ave_DRnmi','var_DRnmi','ave_DRri','var_DRri','ave_Traintime_DR','var_Traintime_DR','ave_Testtime_DR','var_Testtime_DR','ave_betas_DR','-v7.3');

    
    
    
    