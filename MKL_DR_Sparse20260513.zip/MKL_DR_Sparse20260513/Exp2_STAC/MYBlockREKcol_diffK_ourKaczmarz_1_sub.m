function [betas]=MYBlockREKcol_diffK_ourKaczmarz_1_sub(betas,trainfea,y,A,tol,iter,ReducedDim,p1,Degrees_sub,KernelTypes_sub)  %�����ģ���� 
%block randomized extended kaczmarz algorithm(�������(��)��Nystrom��˾������)
%���Ҷ�
global  KernelPostProcessTypes ;
m=length(Degrees_sub);
n=size(trainfea,1); 
m1=floor(p1*n);
% k=m1-10;

X0=betas;
Z0=y;
Bnorm=norm(y);
tstart=tic;
IT=1;
 

hi=floor(m/5);%������

err=1;
q=[];

while err>tol && IT<iter
K_sub=zeros(n*ReducedDim,hi);    
% w1=randperm(m,hi);  
w1=randsrc(1,hi,[1:m; betas']);%������ѡ���

for j=1:hi
    kernel_option = [];
     switch lower(KernelTypes_sub{w1(j)})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    cols = randperm(n,m1); % uniform sampling without replacement 
                    Rtrainfea=trainfea(cols,:);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees_sub(w1(j));
                    cols = randperm(n,m1); % uniform sampling without replacement 
                    Rtrainfea=trainfea(cols,:);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C,KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees_sub(w1(j));
                    cols = randperm(n,m1); % uniform sampling without replacement 
                    Rtrainfea=trainfea(cols,:);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees_sub(w1(j));
                        cols = randperm(n,m1); % uniform sampling without replacement 
                        Rtrainfea=trainfea(cols,:);
                        C = constructKernel(trainfea,Rtrainfea, kernel_option);
                        C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
     end
        W = C(cols,:);  
        W=max(W,W');% m-by-m intersection matrix 
    K_sub(:,j)=reshape(((A'*C)*pinv(W))*C',n*ReducedDim,1);
end

clear Rtrainfea C W
     [U,S,V]=svd(K_sub,'econ');      
%      W=V*(diag(diag(S).^(-1))*(U'*Z0));
     W=V*((diag(S).^(-1)).*(U'*Z0));
     X0(w1',:)=X0(w1',:)+W;
     Z1=Z0-K_sub*W;
     clear K_sub U S V
%     err0=B-A*X1;
%     err1=norm(err0,'fro')^2/norm(B,'fro')^2;
%     err=norm(A'*err0,'fro')^2/norm(A'*B,'fro')^2; 
   
    err=norm(W)/Bnorm;

% err1=norm(X1-X_LS,'fro')/norm(X_LS,'fro');

  
    Z0=Z1;
    IT=IT+1;
    q(IT,1)=err;

end
betas=X0;
time=toc(tstart);
error1=q(end,1);

betas = quadprog(eye(m,m),-betas,[],[],ones(1,m),1,zeros(m,1),ones(m,1));
% betas(betas<betas_tol)=0;
betas(betas<1e-3)=0;
betas = betas/sum(betas);

end
