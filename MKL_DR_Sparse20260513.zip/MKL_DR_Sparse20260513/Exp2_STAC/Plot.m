close all 
clc

%% acc
ave_ACC1=mean(result(:,1,:));
ave_ACC1=reshape(ave_ACC1,3,1);
var_ACC1=var(result(:,1,:));
var_ACC1=reshape(var_ACC1,3,1);
%% nmi
ave_NMI1=mean(result(:,2,:));  
ave_NMI1=reshape(ave_NMI1,3,1);
var_NMI1=var(result(:,2,:));
var_NMI1=reshape(var_NMI1,3,1);
%% ri
ave_RI1=mean(result(:,3,:));
ave_RI1=reshape(ave_RI1,3,1);
var_RI1=var(result(:,3,:));
var_RI1=reshape(var_RI1,3,1);

%%

t = 0:0.02:1;
y0 = -sin(10*t+1).*t.^1/2;
std = 0.2+0.5*t.^2 - 0.5* t;

plot(t,y0,'Color',[0.12,0.576,1],'Marker','o','linewidth',2)
hold on
h=fill([t,t(end:-1:1)],[y0-std,y0(end:-1:1)+std(end:-1:1)],'r');
set(h,'FaceColor',[0.54,0.82,1],'FaceAlpha',0.6,'EdgeColor','none');
