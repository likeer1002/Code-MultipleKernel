close all
clear 
clc   
%2026.04.08
%% ���� ��ά��VSʶ�𾫶�ͼ������Ƕ���㷨


% DataBase='ORL_32x32';     %n=400(ntrain=280)
% DataBase='ORL_64x64';     %n=400(ntrain=280)
% DataBase='COIL20';     %n=1440(ntrain=1008)
% DataBase='YaleB_64x64';   %n=2432(ntrain=1710)
% DataBase='AR_30x40';      %n=2600(ntrain=1900)
% DataBase='sub_USPS';      %n=5000(ntrain=3500)  %%
% DataBase='USPS';             %n=9298(ntrain=)
% DataBase='TDT2';             %n=9394(ntrain=6589)
% DataBase='PIE_32x32';     %n=11560(ntrain=8092)
% DataBase='Facescrub';        %n=22631(ntrain=15956) ��
% DataBase='CIFAR-100';        %n=60000(ntrain=42000)��
% DataBase='MNIST';            %n=70000(ntrain=49005)
% DataBase='Caltech256';
% DataBase='FounderType-17_64x64';
% DataBase='YouTubeFace_128x128_2000';  %n=(ntrain=)

% DataBase='YouTubeFaceArrange_32x32';  %n=370319(ntrain=259369)
% DataBase='YouTubeFace_320x320';  %n=124819(ntrain=87374)

%%
% DataBases={'ORL_32x32','sub_USPS','TDT2','PIE_32x32','MNIST','YouTubeFace_128x128_2000','FounderType-17_64x64'};
% p1s=[0.3,0.1,0.1,0.1,0.1,0.001,0.001]';
% Pre_p1s=[0.1,0.05,0.05,0.05,0.05,0.0005,0.0005]'; 
    DataBase='YaleB_64x64';
    p1=0.3;   %Nystrom�еĲ�������0.1��0.3,�Լ�0.001
    Pre_p1=0.1;    %Sparse��Nystrom�еĲ�������0.05��0.1,0.0005
    ReducedDims=2:2:36;
    ReducedDims=ReducedDims';
global KernelTypes KernelPostProcessTypes Degrees;
KernelTypes = {'Linear', 'PolyPlus', 'PolyPlus', 'PolyPlus',... 
    'Polynomial','Polynomial','Polynomial', 'Gaussian', 'Gaussian',...
    'Gaussian', 'Gaussian', 'Gaussian', 'Gaussian','Gaussian'};
KernelPostProcessTypes = 'MAX'; % KernelPostProcessTypes = {'Sample-Scale'};
Degrees = [1, 2, 4, 6, 2, 4, 6, 0.01, 0.05, 0.1, 1, 10, 50, 100]; % 14 base kernels
m=length(Degrees);
times=5;
% p=[0.4,0.6,0.8]';  %ѡ��p��������Ϊѵ����
p=0.8;  %ѡ��p��������Ϊѵ����
Create_Train_Test_diffp(DataBase,p,times,1);


%%  --------------Our Sparse method--Computing betas -----------------%%
    tol2=1e-2;  max_IT2=20;
    betas_tol=0.07;%1e-6
    max_IT=5;
    Pre_max_IT=2;  %Sparse������������2
    step1=1e-1;% length of step used to update Lagrange multiplier
%     gamma=[2e-2,2e-1,2,2e1,2e2,2e3]';  % a parameter to trade off the clustering cost function and the regularization term.
    gamma=0.1;  %  gamma=0.2;
    lambda=0.1;   % Lagrange multiplier
    ave_Straintime_OURS=zeros(length(ReducedDims),1);
    var_Straintime_OURS=zeros(length(ReducedDims),1);
    betas=zeros(m,times,length(ReducedDims));
for i=1:length(ReducedDims)
    disp('Starting to Compute OurSparseMethod...')
    alg='Precond_OurSparse';
   ReducedDim=ReducedDims(i);  
[BIG_betas,ave_Straintime_OURS(i),var_Straintime_OURS(i),betas(:,:,i)]=...
    OurSparse_diffK_Precond_dimen(times,DataBase,tol2,max_IT2,Pre_max_IT,Pre_p1,betas_tol,gamma,lambda,step1,p,ReducedDim);
end
    filename = strcat(alg,'+',DataBase,'+',num2str(Pre_p1),'+',num2str(betas_tol),'+','multiplep','+','Precondition','.mat'); % �洢���ļ���
    save(strcat('Result','\','Supervised','\','3MKL_DR_Sparse2','\',filename),'Degrees','ave_Straintime_OURS','var_Straintime_OURS','betas','-v7.3');
    disp(['Our Sparse Method������ʱ��:',num2str(ave_Straintime_OURS(length(ReducedDim)))]);
%% --------------Ԥ������Our method 1------------------%%
    ave_PreTraintime_OURS=zeros(length(ReducedDims),1);
    var_PreTraintime_OURS=zeros(length(ReducedDims),1);
    ave_Saccuracy=zeros(length(ReducedDims),1);
    var_Saccuracy=zeros(length(ReducedDims),1);
for i=1:length(ReducedDims)
  ReducedDim=ReducedDims(i);
   disp('Starting to Compute Precond_OurMethod...')
   alg='Precond_OurMethod';
[ave_Saccuracy(i),var_Saccuracy(i),ave_PreTraintime_OURS(i),var_PreTraintime_OURS(i),ave_PreTesttime_OURS(i),var_PreTesttime_OURS(i)]...
    =OurMethod_diffK_Precond_dimen(times,DataBase,tol2,max_IT2,max_IT,p1,p,betas_tol,betas(:,:,i),ReducedDim);
end

    disp(['Our Precond_Method������ʱ��:',num2str(ave_PreTraintime_OURS(length(ReducedDims)))]);
    filename = strcat(alg,'+',DataBase,'+',num2str(p1),'+','multiplep','+','Precondition','.mat'); % �洢���ļ���
    save(strcat('Result','\','Supervised','\','3MKL_DR_Sparse2','\',filename),'Degrees','ReducedDims','ave_Saccuracy','var_Saccuracy','ave_PreTraintime_OURS','var_PreTraintime_OURS','ave_PreTesttime_OURS','var_PreTesttime_OURS','-v7.3');



%% --------------Our method--Computing A by Nystrom method-----------------%%
%     memusage=zeros(length(p),1);
    ave_accuracy=zeros(length(ReducedDims),1);
    var_accuracy=zeros(length(ReducedDims),1);
    ave_Traintime_OURS=zeros(length(ReducedDims),1);
    var_Traintime_OURS=zeros(length(ReducedDims),1);
    ave_Testtime_OURS=zeros(length(ReducedDims),1);
    var_Testtime_OURS=zeros(length(ReducedDims),1);
    ave_betas=zeros(length(Degrees),length(ReducedDims));  
for i=1:length(ReducedDims)
    disp('Starting to Compute OurMethod...')
    alg='OurMethod';
ReducedDim=ReducedDims(i);
    [ave_accuracy(i),var_accuracy(i),ave_Traintime_OURS(i),var_Traintime_OURS(i),ave_Testtime_OURS(i),var_Testtime_OURS(i),ave_betas(:,i)]...
        =OurMethod_31_diffKernel_dimen(times,DataBase,tol2,max_IT2,max_IT,p1,p,ReducedDim);
end

    disp(['Our Method������ʱ��:',num2str(ave_Traintime_OURS(length(ReducedDims)))]);
    filename = strcat(alg,'+',DataBase,'+',num2str(p1),'+','multiplep','.mat'); % �洢���ļ���
    save(strcat('Result','\','Supervised','\','2MKL_DR2','\',filename),'Degrees','ReducedDims','ave_accuracy','var_accuracy','ave_Traintime_OURS','var_Traintime_OURS','ave_Testtime_OURS','var_Testtime_OURS','ave_betas','-v7.3');

close all
clearvars -except  p1 ReducedDims DataBase
clc    



%% ---------- ��˶Ա��㷨  ---------------------------
 global KernelTypes KernelPostProcessTypes Degrees;
KernelTypes = {'Linear', 'PolyPlus', 'PolyPlus', 'PolyPlus',... 
    'Polynomial','Polynomial','Polynomial', 'Gaussian', 'Gaussian',...
    'Gaussian', 'Gaussian', 'Gaussian', 'Gaussian','Gaussian'};
KernelPostProcessTypes = 'MAX'; % KernelPostProcessTypes = {'Sample-Scale'};
Degrees = [1, 2, 4, 6, 2, 4, 6, 0.01, 0.05, 0.1, 1, 10, 50, 100]; % 14 base kernels
m=length(Degrees);
times=3;
% p=[0.4,0.6,0.8]';  %ѡ��p��������Ϊѵ����
p=0.8;  %ѡ��p��������Ϊѵ����
%% -------------MKL_SRTR method------------------%%
    ave_SRTRaccuracy=zeros(length(ReducedDims),1);
    var_SRTRaccuracy=zeros(length(ReducedDims),1);
    ave_Traintime_SRTR=zeros(length(ReducedDims),1);
    var_Traintime_SRTR=zeros(length(ReducedDims),1);
    ave_Testtime_SRTR=zeros(length(ReducedDims),1);
    var_Testtime_SRTR=zeros(length(ReducedDims),1);
    ave_betas_SRTR=zeros(length(Degrees),length(ReducedDims));  
for i=1:length(ReducedDims)
    ReducedDim=ReducedDims(i);
    disp('Starting to Compute MKL_SRTR...')
    alg='MKL_SRTR';
    step1=1; step2=0.5; %length of step
    max_IT1=5;  max_IT2=5;
    [A,betas,ave_SRTRaccuracy(i),var_SRTRaccuracy(i),ave_Traintime_SRTR(i),var_Traintime_SRTR(i),ave_Testtime_SRTR(i),var_Testtime_SRTR(i),ave_betas_SRTR(:,i)]...
        =MKL_SRTR_1_diffKernel_dimen(times,DataBase,step1,max_IT1,step2,max_IT2,p1,p,ReducedDim);
end

    disp(['MKL_SRTR����������ʱ��:',num2str(ave_Traintime_SRTR(length(ReducedDims)))]);
    filename = strcat(alg,'+',DataBase,'+','multiplep','.mat'); % �洢���ļ���
    save(strcat('Result','\','Supervised','\','1Others','\',filename),'Degrees','ReducedDims','ave_SRTRaccuracy','var_SRTRaccuracy','ave_Traintime_SRTR','var_Traintime_SRTR','ave_Testtime_SRTR','var_Testtime_SRTR','ave_betas_SRTR','-v7.3');




%% -------------MKL_TR method------------------%%
    ave_TRaccuracy=zeros(length(ReducedDims),1);
    var_TRaccuracy=zeros(length(ReducedDims),1);
    ave_Traintime_TR=zeros(length(ReducedDims),1);
    var_Traintime_TR=zeros(length(ReducedDims),1);
    ave_Testtime_TR=zeros(length(ReducedDims),1);
    var_Testtime_TR=zeros(length(ReducedDims),1);
    ave_betas_TR=zeros(length(Degrees),length(ReducedDims));  
for i=1:length(ReducedDims)
    ReducedDim=ReducedDims(i);
    disp('Starting to Compute MKL_TR...')
    alg='MKL_TR';
    step1=1; step2=0.5; %length of step
    max_IT1=5;  max_IT2=5;
    lambda_TR=1e-4;
    [ave_TRaccuracy(i),var_TRaccuracy(i),ave_Traintime_TR(i),var_Traintime_TR(i),ave_Testtime_TR(i),var_Testtime_TR(i),ave_betas_TR(:,i)]...
        =MKL_TR_diffKernel_1_dimen(times,DataBase,step1,max_IT1,step2,max_IT2,lambda_TR,p1,p,ReducedDim);
end

    disp(['MKL_TR����������ʱ��:',num2str(ave_Traintime_TR(length(ReducedDims)))]);
    filename = strcat(alg,'+',DataBase,'+','multiplep','.mat'); % �洢���ļ���
    save(strcat('Result','\','Supervised','\','1Others','\',filename),'Degrees','ReducedDims','ave_TRaccuracy','var_TRaccuracy','ave_Traintime_TR','var_Traintime_TR','ave_Testtime_TR','var_Testtime_TR','ave_betas_TR','-v7.3');

% 
% %% -------------MKL_SR method------------------%%
% addpath('./Solver/');
% addpath('./Solver/Mexfun/');
%     ave_SRaccuracy=zeros(length(ReducedDims),1);
%     var_SRaccuracy=zeros(length(ReducedDims),1);
%     ave_Traintime_SR=zeros(length(ReducedDims),1);
%     var_Traintime_SR=zeros(length(ReducedDims),1);
%     ave_Testtime_SR=zeros(length(ReducedDims),1);
%     var_Testtime_SR=zeros(length(ReducedDims),1);
%     ave_betas_SR=zeros(length(Degrees),length(ReducedDims));  
%     Installmex
%     startup
% for i=1:length(ReducedDims)
%     ReducedDim=ReducedDims(i);
%     disp('Starting to Compute MKL_SR...')
%     alg='MKL_SR';
%     max_IT1=5;  
%     [ave_SRaccuracy(i),var_SRaccuracy(i),ave_Traintime_SR(i),var_Traintime_SR(i),ave_Testtime_SR(i),var_Testtime_SR(i),ave_betas_SR(:,i)]...
%         =MKL_SR_diffKernel_dimen(times,DataBase,max_IT1,p1,p,ReducedDim);
% end
% 
%     disp(['MKL_SR����������ʱ��:',num2str(ave_Traintime_SR(length(ReducedDims)))]);
%     filename = strcat(alg,'+',DataBase,'+','multiplep','.mat'); % �洢���ļ���
%     save(strcat('Result','\','Supervised','\','1Others','\',filename),'Degrees','ReducedDims','ave_SRaccuracy','var_SRaccuracy','ave_Traintime_SR','var_Traintime_SR','ave_Testtime_SR','var_Testtime_SR','ave_betas_SR','-v7.3');
% 
% 
% 
% %% -------------MKL_DR method------------------%%
% addpath('./Solver/');
% addpath('./Solver/Mexfun/');
%     ave_DRaccuracy=zeros(length(ReducedDims),1);
%     var_DRaccuracy=zeros(length(ReducedDims),1);
%     ave_Traintime_DR=zeros(length(ReducedDims),1);
%     var_Traintime_DR=zeros(length(ReducedDims),1);
%     ave_Testtime_DR=zeros(length(ReducedDims),1);
%     var_Testtime_DR=zeros(length(ReducedDims),1);
%     ave_betas_DR=zeros(length(Degrees),length(ReducedDims));  
% %     Installmex
%     startup
% for i=1:length(ReducedDims)
%     ReducedDim=ReducedDims(i);
%     disp('Starting to Compute MKL_DR...')
%     alg='MKL_DR';
%     max_IT1=5;  
%     [ave_DRaccuracy(i),var_DRaccuracy(i),ave_Traintime_DR(i),var_Traintime_DR(i),ave_Testtime_DR(i),var_Testtime_DR(i),ave_betas_DR(:,i)]...
%         =MKL_DR_diffKernel_1_dimen(times,DataBase,max_IT1,p1,p,ReducedDim);
% end
% 
%     disp(['MKL_DR����������ʱ��:',num2str(ave_Traintime_DR(length(ReducedDims)))]);
%     filename = strcat(alg,'+',DataBase,'+','multiplep','.mat'); % �洢���ļ���
%     save(strcat('Result','\','Supervised','\','1Others','\',filename),'Degrees','ReducedDims','ave_DRaccuracy','var_DRaccuracy','ave_Traintime_DR','var_Traintime_DR','ave_Testtime_DR','var_Testtime_DR','ave_betas_DR','-v7.3');
% 
% close all
% clearvars -except  p1 ReducedDims DataBase
% clc   
% 
% 
%%  ---------- �Ƕ�˶Ա��㷨  ---------------------------
addpath('./lib');
% dataset='COIL100';
nRepeat=5;  
p=0.8;  %ѡ��p��������Ϊѵ����
data_dir = fullfile(pwd,'DataBase');
%% demo_RSLDA_dimen
for i=1:length(ReducedDims)
    ReducedDim=ReducedDims(i);
    [ave_RSLDAaccuracy(i),var_accuracy(i),ave_time(i),var_traintime(i),var_testtime(i)]...
        =demo_RSLDA_dimen(nRepeat,DataBase,p,ReducedDim);  % RSLDA  2025-07-12
end
    filename = strcat('RSLDA','+',DataBase,'+',num2str(p),'.mat'); % �洢���ļ���
    save(strcat('Result','\','NonMultiKernel','\',filename),'ReducedDims','ave_RSLDAaccuracy','var_accuracy','var_traintime','ave_time','var_testtime','-v7.3');


%% ��ͼ
figure
plot(ReducedDims,ave_Saccuracy,'r-*','linewid',3);
hold on
plot(ReducedDims,ave_accuracy,'b-*','linewid',3);
hold on
plot(ReducedDims,ave_SRTRaccuracy,'g-*','linewid',3);
hold on
plot(ReducedDims,ave_TRaccuracy,'y-*','linewid',3);
hold on
plot(ReducedDims,ave_RSLDAaccuracy,'k-*','linewid',3);
hold off

title(DataBase);
xlabel('Dimension of Projected Data'); % x���Ǵ�С,����
ylabel('Recognition Rate'); % y���Ǵ�С,����
legend('Algorithm 7','Algorithm 4','MKL-SRTR','MKL-TR','RSLDA');%ͼ��
