function [betas,time]=QRComputing_betas_1(trainfea,y,A,ReducedDim,width,p1)  %�����ģ���� 
%�����γ�ϵ��������QR�ֽ�
%���Ҷ�
m=length(width);
n=size(trainfea,1); 
m1=floor(p1*n);

tstart=tic;
K_sub=zeros(n*ReducedDim,m);
for i=1:m
           options=[];
           options.KernelType = 'Gaussian';
           options.t=width(i);
           cols = randperm(n,m1); % uniform sampling without replacement 
           Rtrainfea=trainfea(cols,:);

           C= constructKernel(trainfea,Rtrainfea,options);
           W = C(cols,:);  
           W=max(W,W');% m-by-m intersection matrix
    %         K_i = constructKernel(trainfea,[],options);  
        K_sub(:,i)=reshape(((A'*C)*pinv(W))*C',n*ReducedDim,1);

end 
clear  Rtrainfea C W


[Q,R]=qr(K_sub,0);
clear K_sub 
betas=R\(Q'*y);
% betas=(R'*R)\(R'*(Q'*y));

time=toc(tstart);

end
