function M = calM(trainfea,width,p1)
% ����˾���֮�������Ծ���
m=length(width);
n=size(trainfea,1);
m1=floor(p1*n);
cols = randperm(n,m1); % uniform sampling without replacement 
Rtrainfea=trainfea(cols,:);

M = zeros(m);
for i =1:m-1
    for j = i+1:m
        options=[];
        options.KernelType = 'Gaussian';
        options.t=width(i);
        kernel_sub_i= constructKernel(trainfea,Rtrainfea,options);
        [Qi,~]=qr(kernel_sub_i,0);    
        options=[];
        options.KernelType = 'Gaussian';
        options.t=width(j);
        kernel_sub_i= constructKernel(trainfea,Rtrainfea,options);
        [Qj,~]=qr(kernel_sub_i,0); 

        M(i,j) = norm(Qj'*Qi);
    end
end
% M = (M+M')-diag(diag(M));
M = (M+M')+eye(m);
clear Rtrainfea kernel_sub_i Qi Qj
end