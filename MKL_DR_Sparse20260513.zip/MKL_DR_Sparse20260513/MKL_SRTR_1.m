function [ave_accuracy,var_accuracy,ave_traintime_SRTR,var_traintime_SRTR,ave_betas]...
    =MKL_SRTR_1(times,DataBase,width,step1,max_IT1,step2,max_IT2)
%  ��MKL_SRTR����Multiple kernel dimensionality reduction via spectral regression and trace ratio maximization
accuracy=zeros(times,1);
time_SRTR_train=zeros(times,1);
m=length(width);
Betas=zeros(m,times);
for j = 1:times
tstart=tic;
     file = strcat(DataBase,'\','Train\',int2str(j),'.mat');
     load(file, 'trainfea','traingnd');
%      eval(['load ' DataBase, '\','Train\',int2str(j),'.mat']); 
     nclass=length(unique(traingnd));  %�ܹ��������
     ReducedDim=nclass-1;
     n=size(trainfea,1);  %ѵ������������

%       options = [];
%       options.NeighborMode = 'KNN';
%       options.k = 5;
%       options.WeightMode = 'HeatKernel';
      options = [];
      options.NeighborMode = 'Supervised';
      options.gnd = traingnd;
      options.bLDA = 1;
%       options.WeightMode = 'HeatKernel';    
W = constructW(trainfea,options); %%% sparse Affinity matrix
D=full(sum(W,2));   %Column vector
% D=sparse(diag(D));   % Diagonal matrix  D
KERNELS=zeros(n,n,m);
for i=1:m
options=[];
options.KernelType = 'Gaussian';
options.t=width(i);
KERNELS(:,:,i)=constructKernel(trainfea,[],options);
end

r=1;
f_r=1;
it=1;
while f_r~=0 && it<max_IT1
    [A,betas]=MKL_SRTR_ADM_1(KERNELS,D,W,n,nclass,ReducedDim,r,step2,max_IT2,m); %Alternating projections
    Kernel=zeros(n,n);
  for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
  
     [~,deltas_D]=eig(Kernel*(W-r*D)*Kernel);
%     sigma=eigs(@(x)KWDKtimesx(Kernel,W,D,r,x),n,ReducedDim,'lm');%���
    f_r=sum(diag(deltas_D));
    C=D.^(1/2).*Kernel*A;
    d_f_r=-norm(C,'fro')^2;
    r=r-step1*f_r/d_f_r;
    d_betas=zeros(m,1);
  for i=1:m
    d_betas(i)=trace(2*A'*KERNELS(:,:,i)*(W-r*D)*Kernel*A);  
  end
    betas=betas+step2*d_betas/norm(d_betas);  
%     e=ones(m,1);
%     cvx_begin
%        variable p(m)
%        minimize(norm(p-betas,2)^2)
%        subject to
%           p'*e==1;
%           p>=0;  
%     cvx_end
%     betas=p;
  betas = quadprog(eye(m,m),-betas,[],[],ones(1,m),1,zeros(m,1),ones(m,1));
  it=it+1;
end   %end while
time_SRTR_train(j)=toc(tstart);
Betas(:,j)=betas;
    Kernel=zeros(n,n);
  for i=1:m
    Kernel=Kernel+betas(i)*KERNELS(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
 %%%--------- Data projected in the learned representation space-----------
trainData = zeros(n,size(A,2));    % size(A,2)=nclass-1
for i =1:n
    trainData(i,:) = Kernel(i,:)*A;
end
load(file, 'testfea','testgnd');
ntest=size(testfea,1);
KERNELS_test=zeros(n,ntest,m);
for i=1:m
options=[];
options.KernelType = 'Gaussian';
options.t=width(i);
KERNELS_test(:,:,i)=constructKernel(trainfea,testfea,options);
end
    Kernel_test=zeros(n,ntest);
  for i=1:m
    Kernel_test=Kernel_test+betas(i)*KERNELS_test(:,:,i);  %The mixed kernel, i.e., Convex combinations of all kernel matrices
  end
testData = zeros(ntest,size(A,2));    % size(A,2)=nclass-1
for i =1:ntest
     testData_no= A'*Kernel_test(:,i);
     testData(i,:)=testData_no';
end
accuracy(j)=NN(trainData,testData,traingnd,testgnd);

end %end times
ave_accuracy=mean(accuracy);    var_accuracy=var(accuracy);
ave_traintime_SRTR=mean(time_SRTR_train);  var_traintime_SRTR=var(time_SRTR_train);
ave_betas=mean(Betas,2);
save('SRTR_ORL_7.mat','accuracy','time_SRTR_train','Betas');
end

