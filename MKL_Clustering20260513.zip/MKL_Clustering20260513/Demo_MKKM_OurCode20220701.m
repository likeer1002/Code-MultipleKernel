
%% Our Code  2022-07-01
function Demo_MKKM_OurCode20220701(n, nRepeat,p1)
% global KernelTypes KernelPostProcessTypes Degrees;
addpath('./OurCode/');
% datasets={'AR_840n_768d_120c_uni','binaryalphadigs_1404n_320d_36c',...
%     'COIL20_1440n_1024d_20c','jaffe_213n_676d_10c_uni',...
%     'ORL_400n_1024d_40c_zscore_uni','tr11_414n_6429d_9c_tfidf_uni',...
%     'tr41_878n_7454d_10c_tfidf_uni','tr45_690n_8261d_10c_tfidf_uni',...
%     'YALE_165n_1024d_15c_zscore_uni'};
datasets={'AR_30x40_uni'};
dataset=datasets{n};  %ѡ�����ݼ�3,7
data_dir = fullfile(pwd,'dataset');
% m=length(Degrees);
%%


lambdas=[2.^(-3:3)];
% lambdas=[2.^(-12:12)];      %���򻯲���gamma��Ӱ��

load(fullfile(data_dir,dataset),'y');  %��ʵ��ǩ
nClass = length(unique(y));

result_dir = fullfile(pwd,['result_MKKM_OurCode_' num2str(nRepeat)],[dataset,'_result']);
if ~exist(result_dir,'dir')
    mkdir(result_dir);
end



disp('Our MKKM with Representative Kernels begin ...');
for i = 1:length(lambdas)
    disp(['The ',num2str(i),'-th ','lambda',' ','begin.']);
    lambda=lambdas(i);
    mkkm_Ours_result = zeros(nRepeat,3);
%     obj_final = cell(nRepeat,1);
    kw_aio = cell(nRepeat,1);
    suffix = num2str(lambda);
    result_file = fullfile(result_dir,[dataset,'_MKKM_OurCode_' suffix '.mat']);
    % rng('default');
    T_3=zeros(nRepeat,1);  %��ʱMKKM_RK
    max_IT=20;
    betas_tol=0.07;
    for iRepeat = 1:nRepeat
        t_3 = tic;
        disp(['MKKM_OurCode ',num2str(iRepeat),' of ' num2str(nRepeat), ' iteration begin ...']);

        [label,kw] = Our_MKKM(lambda,max_IT,p1,betas_tol,dataset);
        mkkm_Ours_result(iRepeat,:) = ClusteringMeasure(y,label);
        kw_aio{iRepeat} = kw;
        T_3(iRepeat)=toc(t_3);
        disp(['MKKM_OurCode ',num2str(iRepeat),' of ' num2str(nRepeat),' iterations done.']);
        disp(['MKKM_OurCode exe time: ',num2str(T_3(iRepeat))]);
    end
    if size(mkkm_Ours_result,1) > 1
        mkkm_Ours_result_mean = mean(mkkm_Ours_result);
        runtime=mean(T_3);
    else
        mkkm_Ours_result_mean = mkkm_Ours_result;
        runtime=T_3;
    end
    Allruntime=runtime;
    save(result_file,'mkkm_Ours_result','mkkm_Ours_result_mean',...
        'kw_aio','Allruntime');
    disp('MKKM_OurCode on multi kernel done');
end
end