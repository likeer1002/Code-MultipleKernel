    close all
    clear 
    clc
    %% mkkm_rk   (Time �Լ�1-acc,1-nmi,1-purity)
% datasets={'AR_840n_768d_120c_uni','binaryalphadigs_1404n_320d_36c',...
%     'COIL20_1440n_1024d_20c','jaffe_213n_676d_10c_uni',...
%     'ORL_400n_1024d_40c_zscore_uni','tr11_414n_6429d_9c_tfidf_uni',...
%     'tr41_878n_7454d_10c_tfidf_uni','tr45_690n_8261d_10c_tfidf_uni',...
%     'YALE_165n_1024d_15c_zscore_uni'};
datasets={'AR_30x40_uni','sub_USPS_uni','TDT2_uni','PIE_32x32_uni','MNIST_uni'};
    dataset=datasets{4};  %ѡ�����ݼ�3,2,7,1
    lambdas=[2.^(-3:3)];
% lambdas=[0.1:0.2:0.9];
    nRepeat=5;  %�ظ�����
    % result_mkkm_rk_sfn,result_rmkkm_,
    result_dir = fullfile(pwd,['result_mkkm_rk_sfn' num2str(nRepeat)],[dataset,'_result']);
    Finalmkkm_rk_result_Mean=[];
    FinalAllRunTime=[];
    for i = 1:length(lambdas)
    lambda=lambdas(i);
    suffix = num2str(lambda);
    result_file = fullfile(result_dir,[dataset,'_mkkm_rk_' suffix '.mat']);
    load(result_file,'mkkm_rk_result_mean','Allruntime');
%     mkkm_rk_result_mean=1-mkkm_rk_result_mean;  %��average rankԽСԽ��
    Finalmkkm_rk_result_Mean=[Finalmkkm_rk_result_Mean;mkkm_rk_result_mean];
    FinalAllRunTime=[FinalAllRunTime;Allruntime];
    end
    Finalmkkm_rk_result_Mean=mean(Finalmkkm_rk_result_Mean,1);  %ָ�꣺ACC,NMI,Purity
    FinalAllRunTime=mean(FinalAllRunTime);  %���������ʱ�䣬�������˾������ʱ��
    
    
    