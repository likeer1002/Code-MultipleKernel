    close all
    clear 
    clc
    %% mkkm_MR  (Time �Լ�1-acc,1-nmi,1-purity)
% datasets={'AR_840n_768d_120c_uni','binaryalphadigs_1404n_320d_36c',...
%     'COIL20_1440n_1024d_20c','jaffe_213n_676d_10c_uni',...
%     'ORL_400n_1024d_40c_zscore_uni','tr11_414n_6429d_9c_tfidf_uni',...
%     'tr41_878n_7454d_10c_tfidf_uni','tr45_690n_8261d_10c_tfidf_uni',...
%     'YALE_165n_1024d_15c_zscore_uni'};
datasets={'AR_30x40_uni','sub_USPS_uni','TDT2_uni','PIE_32x32_uni','MNIST_uni'};
    dataset=datasets{4};  %ѡ�����ݼ�3,2,7,1
    lambdas=[2.^(-3:3)];
%     lambdas=[2.^(-12:12)];

    nRepeat=5;  %�ظ�����
    result_dir = fullfile(pwd,['result_MKKM_MR_' num2str(nRepeat)],[dataset,'_result']);
    Finalmkkm_rk_result_Mean=[];
    FinalAllRunTime=[];
    for i = 1:length(lambdas)
    lambda=lambdas(i);
    suffix = num2str(lambda);
    result_file = fullfile(result_dir,[dataset,'_MKKM_MR_' suffix '.mat']);
    load(result_file,'MKKM_MR_result_mean','Allruntime');
%     MKKM_MR_result_mean=1-MKKM_MR_result_mean;  %��average rankԽСԽ��
    Finalmkkm_rk_result_Mean=[Finalmkkm_rk_result_Mean;MKKM_MR_result_mean];
    FinalAllRunTime=[FinalAllRunTime;Allruntime];
    end
    F11inalmkkm_rk_result_Mean=mean(Finalmkkm_rk_result_Mean,1);  %ָ�꣺ACC,NMI,Purity
    FinalAllRunTime=mean(FinalAllRunTime);  %���������ʱ�䣬�������˾������ʱ��
%     
% plot(Finalmkkm_rk_result_Mean(:,1));
% hold on
% plot(Finalmkkm_rk_result_Mean(:,2));
% hold on 
% plot(Finalmkkm_rk_result_Mean(:,3));
    