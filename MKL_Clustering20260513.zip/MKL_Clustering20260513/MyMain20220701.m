% close all
% clear
% clc
% %%  ���еıȽ��㷨 20220701 
% addpath('./lib');
% % datasets={'AR_840n_768d_120c_uni','binaryalphadigs_1404n_320d_36c',...
% %     'COIL20_1440n_1024d_20c','jaffe_213n_676d_10c_uni',...
% %     'ORL_400n_1024d_40c_zscore_uni','tr11_414n_6429d_9c_tfidf_uni',...
% %     'tr41_878n_7454d_10c_tfidf_uni','tr45_690n_8261d_10c_tfidf_uni',...
% %     'YALE_165n_1024d_15c_zscore_uni'};
% datasets={'AR_30x40_uni','sub_USPS_uni','TDT2_uni','PIE_32x32_uni','MNIST_uni'};
% for n=1:5
% % n=2;   %ѡ�����ݼ�2,3
% nRepeat=5;
% dataset=datasets{n};  
% data_dir = fullfile(pwd,'dataset');
% %%  �������еĻ��˾���
% global T_1
% t_1=tic;
% [f] = build_kernels(dataset)  %�������еĻ��˾��� ,MNIST_uni�˾䳬�ڴ�
% T_1=toc(t_1)  %�������еĻ��˾����ʱ��
% 
% Demo_sb_mkkm20220701(n, nRepeat);   % SB_KKM  2022-07-01
% Demo_a_mkkm20220701(n, nRepeat);  % A-MKKM  2022-07-01
% Demo_mkkm20220701(n, nRepeat);    % MKKM  2022-07-01
% % Demo_lmkkm20220701(n, nRepeat);   % LMKKM  2022-07-01  ȱһ������
% Demo_rmkkm20220701(n, nRepeat);   % RMKKM  2022-07-01
% Demo_MKKM_MR20220701(n, nRepeat); % MKKM_MR  2022-07-01
% Demo_mkkm_rk_sfn20220701(n, nRepeat);  % MKKM_RK  2022-07-01
% end

%%  Our Code  2022-07-01
close all
clear
clc

global KernelTypes KernelPostProcessTypes Degrees;
KernelTypes = {'Linear', 'PolyPlus', 'PolyPlus', 'PolyPlus',... 
    'Polynomial','Polynomial','Polynomial', 'Gaussian', 'Gaussian',...
    'Gaussian', 'Gaussian', 'Gaussian', 'Gaussian','Gaussian'};
KernelPostProcessTypes = 'MAX'; % KernelPostProcessTypes = {'Sample-Scale'};
Degrees = [1, 2, 4, 6, 2, 4, 6, 0.01, 0.05, 0.1, 1, 10, 50, 100]; % 14 base kernels
m=length(Degrees);


% datasets={'AR_840n_768d_120c_uni','binaryalphadigs_1404n_320d_36c',...
%     'COIL20_1440n_1024d_20c','jaffe_213n_676d_10c_uni',...
%     'ORL_400n_1024d_40c_zscore_uni','tr11_414n_6429d_9c_tfidf_uni',...
%     'tr41_878n_7454d_10c_tfidf_uni','tr45_690n_8261d_10c_tfidf_uni',...
%     'YALE_165n_1024d_15c_zscore_uni'};
datasets={'AR_30x40_uni'};
for n=1
% n=2;   %ѡ�����ݼ�2,3
nRepeat=5;
dataset=datasets{n};  
data_dir = fullfile(pwd,'dataset');
 switch lower(dataset)
     case lower('ar_30x40_uni')
     p1=0.1;  %Nystrom�еĲ�������0.1��0.3
     otherwise
     p1=0.05;  %Nystrom�еĲ�������0.1��0.3         
 end
 p1
Demo_MKKM_OurCode20220701(n, nRepeat,p1); % Our Code  2022-07-01
end


