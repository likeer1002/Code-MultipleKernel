%% MKKM_MR  2022-07-01
function Demo_MKKM_MR20220701(n, nRepeat)
global T_1
addpath('./MKKM_MR/');
addpath('./lib');
% datasets={'AR_840n_768d_120c_uni','binaryalphadigs_1404n_320d_36c',...
%     'COIL20_1440n_1024d_20c','jaffe_213n_676d_10c_uni',...
%     'ORL_400n_1024d_40c_zscore_uni','tr11_414n_6429d_9c_tfidf_uni',...
%     'tr41_878n_7454d_10c_tfidf_uni','tr45_690n_8261d_10c_tfidf_uni',...
%     'YALE_165n_1024d_15c_zscore_uni'};
datasets={'AR_30x40_uni','sub_USPS_uni','TDT2_uni','PIE_32x32_uni','MNIST_uni'};
dataName=datasets{n};  %ѡ�����ݼ�3,8
data_dir = fullfile(pwd,'dataset');
% dataName = 'proteinFold'; %%% flower17; flower102; proteinFold,caltech101_mit,UCI_DIGIT,ccv
%% %% washington; wisconsin; texas; cornell
%% caltech101_nTrain5_48
%% proteinFold
t_2=tic;
kernel_dir = fullfile(pwd,'kernels',[dataName,'_kernel']);
file_list = dir(kernel_dir);
kernel_list = {};
iKernel = 0;
for iFile = 1:length(file_list)
    sName = file_list(iFile).name;
    if (~strcmp(sName,'.') && ~strcmp(sName,'..'))
        iKernel = iKernel+1;
        kernel_list{iKernel} = sName;  %���л��˾������ڵ�.mat
    end
end

load(fullfile(data_dir,dataName),'y');  %��ʵ��ǩ
numclass = length(unique(y));

result_dir = fullfile(pwd,['result_MKKM_MR_' num2str(nRepeat)],[dataName,'_result']);
if ~exist(result_dir,'dir')
    mkdir(result_dir);
end

nKernel = length(kernel_list);
Ks = zeros(length(y),length(y),nKernel);

for iKernel = 1:length(kernel_list)
    iFile = kernel_list{iKernel};
    load(fullfile(kernel_dir,iFile),'K');
    Ks(:,:,iKernel) = K;    %���л��˾���
end


% load([path,'datasets\',dataName,'_Kmatrix.mat'],'KH','Y');
% load([path,'datasets\',dataName,'_Kmatrix'],'KH','Y');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numker = size(Ks,3);
num = size(Ks,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ks = kcenter(Ks);
Ks = knorm(Ks);
qnorm = 2;

% % %%---MKKM-MR(AAAI2016)---%%

Htrntrn = calM(Ks);
lambdaset8 = 2.^[-3:1:3];
% accval8 = zeros(length(lambdaset8),1);
% nmival8 = zeros(length(lambdaset8),1);
% purval8 = zeros(length(lambdaset8),1);
T_2=toc(t_2);
for il =1:length(lambdaset8)
    MKKM_MR_result = zeros(nRepeat,3);
    obj_final = cell(nRepeat,1);
    kw_aio = cell(nRepeat,1);
    suffix = num2str(lambdaset8(il));
    result_file = fullfile(result_dir,[dataName,'_MKKM_MR_' suffix '.mat']);
    T_3=zeros(nRepeat,1);  %��ʱMKKM_RK
    for iRepeat = 1:nRepeat
        t_3=tic;
        [H_normalized8,gamma81,obj81] = myregmultikernelclustering(Ks,Htrntrn,numclass,lambdaset8(il));
        res8 = myNMIACC(H_normalized8,y,numclass);
        kw_aio{iRepeat} = gamma81;
        obj_final{iRepeat} = obj81;
%         accval8(il) = res8(1);
%         nmival8(il) = res8(2);
%         purval8(il) = res8(3);
        MKKM_MR_result(iRepeat,:) = res8;
        T_3(iRepeat)=toc(t_3);
    end
    if size(MKKM_MR_result,1) > 1
        MKKM_MR_result_mean = mean(MKKM_MR_result);
        runtime=mean(T_3);
    else
        MKKM_MR_result_mean = MKKM_MR_result;
        runtime=T_3;
    end
    Allruntime=T_1+T_2+runtime;
    save(result_file,'MKKM_MR_result','MKKM_MR_result_mean','kernel_list',...
        'kw_aio','obj_final','Allruntime');
    disp('MKKM_MR on multi kernel done');
end
end