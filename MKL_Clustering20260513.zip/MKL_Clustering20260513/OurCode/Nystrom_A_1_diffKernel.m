function H=Nystrom_A_1_diffKernel(trainfea,betas,betas_tol,nclass,p1)
global KernelTypes KernelPostProcessTypes Degrees;
m=length(Degrees);
n=size(trainfea,1);
% m1=nclass+10;
m1=floor(n*p1);
idx = randperm(n); % uniform sampling without replacement 
cols = idx(1:m1);    % m columns indexes
Rtrainfea=trainfea(cols,:);
%%%--------computing some columns,i.e., C-------%%%%%

C=zeros(n,m1);
for j=1:m
    if betas(j)>betas_tol
     kernel_option = [];
     switch lower(KernelTypes{j})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(j);
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(j);
                    kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                    kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(j);
                        kernel_sub = constructKernel(trainfea,Rtrainfea, kernel_option);
                        kernel_sub = KernelNormalize(kernel_sub, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
     end
        C=C+betas(j)^2*kernel_sub;
    end
end
clear kernel_sub trainfea Rtrainfea

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
W = C(cols,:);  
W=max(W,W');% m-by-m intersection matrix
[Q,R] = qr (C,0); % thin QR decomposition of matrix C
W =R * pinv(W) * R'; 
W=max(W,W');
[H,~,~] = svd(W,'econ');
H=H(:,1:nclass);
% D=D(1:k,1:k);
H=Q*H;


%%%-------����Nystrom�����Ľ���Ч��---------%%%
% K_app=V*D*V';
% KERNELS=zeros(n,n,m);
% for i=1:m
%     options=[];
%     options.KernelType = 'Gaussian';
%     options.t=width(i);
%    KERNELS(:,:,i) = constructKernel(trainfea,[],options);
% end
% Kernel=zeros(n,n);
% for j=1:m
%     Kernel=Kernel+betas(j)*KERNELS(:,:,j);
% end
% err = norm ( Kernel-K_app, 'fro')/norm(Kernel,'fro');
% err_1=norm(Kernel*A-Y,'fro');
% err_2=norm(Kernel*A-Y,'fro')/norm(Y,'fro');
end


