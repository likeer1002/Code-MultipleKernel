function [idx,betas] = Our_MKKM(lambda,max_IT,p1,betas_tol,dataset)
global  Degrees;
% Input
%   cluster : desired number of clusters
%   error : stop threshold
%   lambda : tradeoff parameter of diversity regularization

% Output
%   idx : N x 1 cluster indices of each observation
%   H_normalized : k-dimensional representations of the samples on the unit sphere
m=length(Degrees);     
betas=ones(m,1)/m;
betas_0=zeros(m,1);
data_dir = fullfile(pwd, 'dataset');     
load(fullfile(data_dir, dataset));     
nclass=length(unique(y));  %�ܹ��������
% n=size(X,1);  %ѵ������������     
     

IT=1;
while IT<max_IT  && norm(betas-betas_0,inf)>=1e-2 && nnz(betas)/length(betas)>=0.5
betas_0=betas;
% ����H
H=Nystrom_A_1_diffKernel(X,betas,betas_tol,nclass,p1);
% ����betas_tilde
[betas_tilde] = Compute_betasTilde(X,H,p1,betas,nclass,lambda);
%����betas
betas=betas_tilde.^(1/2);
betas = quadprog(eye(m,m),-real(betas),[],[],ones(1,m),1,zeros(m,1),ones(m,1));
betas(betas<betas_tol)=0;
betas = betas/sum(betas);
IT=IT+1;
IT
end
H_normalized = H ./ repmat(sqrt(sum(H.^2, 2)), 1, nclass); % the norm of each row of the matrix H_normalized is 1
% idx = kmeans(H_normalized,nclass,'MaxIter',100,'Replicates',10);
idx = kmeans(H_normalized,nclass,'MaxIter',1000,'Replicates',10);
end

