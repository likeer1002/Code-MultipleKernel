function [betas_tilde] = Compute_betasTilde(trainfea,H,p1,betas,nclass,lambda)
global KernelTypes KernelPostProcessTypes Degrees;
bb = calM_diffKernel_Parallel(trainfea,p1); %�˾���֮�������Ծ���M���к�
m=length(Degrees);
n=size(trainfea,1);
% m1=nclass+10;
m1=floor(n*p1);
idx = randperm(n); % uniform sampling without replacement 
cols = idx(1:m1);    % m columns indexes
Rtrainfea=trainfea(cols,:);
alpha=zeros(m,1);
for i=1:m
    kernel_option = [];
     switch lower(KernelTypes{i})
        case lower('Linear')
            kernel_option.KernelType = 'Linear';
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        case lower('Polynomial')
            kernel_option.KernelType = 'Polynomial';
                kernel_option.d = Degrees(i);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        case lower('PolyPlus')
            kernel_option.KernelType = 'PolyPlus';
                kernel_option.d = Degrees(i);
                    C = constructKernel(trainfea,Rtrainfea, kernel_option);
                    C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        case lower('Gaussian')
            kernel_option.KernelType = 'Gaussian';
                kernel_option.t = Degrees(i);
                        C = constructKernel(trainfea,Rtrainfea, kernel_option);
                        C = KernelNormalize(C, KernelPostProcessTypes);%#ok
        otherwise
            error('KernelType does not exist!');
    end 
W = C(cols,:);  
W=max(W,W');% m-by-m intersection matrix
[Q,R] = qr (C,0); % thin QR decomposition of matrix C
W =R * pinv(W) * R'; 
W=max(W,W');
[V,D,~] = svd(W,'econ');
V=V(:,1:nclass);
V=Q*V;
D=diag(D);
D=D(1:nclass);
alpha(i)=sum(D)-norm(D.^(1/2).*(V'*H),'fro')^2;
end
zeta=alpha+lambda*bb;
zeta=zeta/norm(zeta,2);
betas_tilde=betas-zeta*(zeta'*betas);

end

