    close all
    clear 
    clc
    %% ours  (Time �Լ�1-acc,1-nmi,1-purity)
% datasets={'AR_840n_768d_120c_uni','binaryalphadigs_1404n_320d_36c',...
%     'COIL20_1440n_1024d_20c','jaffe_213n_676d_10c_uni',...
%     'ORL_400n_1024d_40c_zscore_uni','tr11_414n_6429d_9c_tfidf_uni',...
%     'tr41_878n_7454d_10c_tfidf_uni','tr45_690n_8261d_10c_tfidf_uni',...
%     'YALE_165n_1024d_15c_zscore_uni'};
datasets={'AR_30x40_uni'};
    dataset=datasets{1};  %ѡ�����ݼ�3,2,7,1
    lambdas=[2.^(-3:3)];
    % lambdas=[2.^(-12:12)];

    nRepeat=5;  %�ظ�����
    result_dir = fullfile(pwd,['result_MKKM_OurCode_' num2str(nRepeat)],[dataset,'_result']);
    Finalmkkm_rk_result_Mean=[];
    Finalmkkm_rk_result_Std=[];
    FinalAllRunTime=[];
    for i = 1:length(lambdas)
    lambda=lambdas(i);
    suffix = num2str(lambda);
    result_file = fullfile(result_dir,[dataset,'_MKKM_OurCode_' suffix '.mat']);
    load(result_file,'mkkm_Ours_result','mkkm_Ours_result_mean','Allruntime');
%     mkkm_Ours_result_mean=1-mkkm_Ours_result_mean;  %��average rankԽСԽ��
    Finalmkkm_rk_result_Std=[Finalmkkm_rk_result_Std;std(mkkm_Ours_result,0,1)];
    Finalmkkm_rk_result_Mean=[Finalmkkm_rk_result_Mean;mkkm_Ours_result_mean];
    FinalAllRunTime=[FinalAllRunTime;Allruntime];
    end
    F11inalmkkm_rk_result_Mean=mean(Finalmkkm_rk_result_Mean,1);  %ָ�꣺ACC,NMI,Purity
    FinalAllRunTime=mean(FinalAllRunTime);  %���������ʱ�䣬�������˾������ʱ��

%% ��ͼ--�������򻯲���
lambdas_log=log2(lambdas);
Finalmkkm_rk_result_Mean=Finalmkkm_rk_result_Mean';
Finalmkkm_rk_result_Std=Finalmkkm_rk_result_Std';
figure
plot(lambdas_log,Finalmkkm_rk_result_Mean(1,:),'r-+','linewid',3);  %��ɫ
hold on
plot(lambdas_log,Finalmkkm_rk_result_Mean(2,:),'k-*','linewid',3);
hold on 
plot(lambdas_log,Finalmkkm_rk_result_Mean(3,:),'b-^','linewid',3);  %��ɫ
hold on
T = legend('ACC', 'NMI', 'Purity');% 'UODV','LUDT','LUDP','LDE','LULDE'

fill([lambdas_log,fliplr(lambdas_log)],[Finalmkkm_rk_result_Mean(1,:)-Finalmkkm_rk_result_Std(1,:),fliplr(Finalmkkm_rk_result_Mean(1,:)+Finalmkkm_rk_result_Std(1,:))],[0.9451 0.2706 0.0745],'edgecolor','none');
alpha(0.2);  %alpha(0.2)������20%�ı���͸���ȣ�
hold on
fill([lambdas_log,fliplr(lambdas_log)],[Finalmkkm_rk_result_Mean(2,:)-Finalmkkm_rk_result_Std(2,:),fliplr(Finalmkkm_rk_result_Mean(2,:)+Finalmkkm_rk_result_Std(2,:))],[0.4314 0.4823 0.5451],'edgecolor','none');
% hold on
alpha(0.2);  %alpha(0.2)������20%�ı���͸���ȣ�
hold on
fill([lambdas_log,fliplr(lambdas_log)],[Finalmkkm_rk_result_Mean(3,:)-Finalmkkm_rk_result_Std(3,:),fliplr(Finalmkkm_rk_result_Mean(3,:)+Finalmkkm_rk_result_Std(3,:))],[0.3010 0.7450 0.9330],'edgecolor','none');
% hold on
alpha(0.2);  %alpha(0.2)������20%�ı���͸���ȣ�
hold off    

title('Database');
xlabel('$\bf{\log_2{\gamma}}$','FontName','Times New Roman','FontSize',16,'Interpreter','latex');%,'FontAngle','italic'); % x���Ǵ�С,����
ylabel('Clustering Performance'); % y���Ǵ�С,����

